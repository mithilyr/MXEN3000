// Curtin University
// Mechatronics Engineering
// White Line Following Robot - ROBOT (PCB) NANO
//
// Automatic Bang-Bang line following using two IR sensors,
// remote Start/Stop + manual motor control from the PC GUI over XBee.
//
// --------------------------------------------------
// WIRING / COMMUNICATION
// --------------------------------------------------
// XBee is connected to the HARDWARE serial pins of the Nano:
//   XBee DOUT -> Nano D0 (RX)
//   XBee DIN  <- Nano D1 (TX)
// (Pins 2-11 and A0-A5 are used by the two DACs, so SoftwareSerial
//  cannot be used here.)
//
// !! Unplug the XBee (or its RX line) while uploading this sketch,
//    because the USB upload also uses pins D0/D1.
//
// Baud rate: 38400 (must match the XBee configuration and the
//            laptop-side bridge Nano).
//
// --------------------------------------------------
// 4-BYTE PROTOCOL:  [255][COMMAND][DATA][CHECKSUM]
//   CHECKSUM = (255 + COMMAND + DATA) mod 256
//
// PC -> Robot commands:
//   0 = request Left IR      (reply on port 0)
//   1 = request Right IR     (reply on port 1)
//   2 = set Left motor  = DATA   (switches to manual mode)
//   3 = set Right motor = DATA   (switches to manual mode)
//   4 = START automatic line following
//   5 = STOP (motors to neutral, manual mode)
//   6 = request status       (replies on ports 6, 7, 8, 9)
//   7 = set line following speed = DATA (0-100 %)
//   8 = set correction wheel speed = DATA (0-100 % of speed, 0 = stop)
//   9 = set direction = DATA (0 = forward, 1 = reverse)
//  10 = request ALL  (one request -> replies on ports 0, 1, 6, 7, 8, 9)
//  11 = request link statistics (replies on ports 10, 11, 12)
//
// Robot -> PC replies:
//   port 0 = Left IR  (0-255, = 10-bit reading / 4)
//   port 1 = Right IR (0-255)
//   port 6 = Left motor output  (0-255)
//   port 7 = Right motor output (0-255)
//   port 8 = mode (1 = automatic running, 2 = searching for lost
//                  line, 0 = stopped/manual)
//   port 9 = direction (0 = forward, 1 = reverse)
//   port 10 = good packets received by the robot   (counter, wraps at 256)
//   port 11 = bad-checksum packets seen by the robot (counter, wraps at 256)
//   port 12 = stray bytes discarded by the robot   (counter, wraps at 256)
// --------------------------------------------------

// --------------------------------------------------
// DAC PIN CONNECTIONS (UNCHANGED)
// --------------------------------------------------

const byte DACPIN1[8] = {
  A2, A3, A4, A5, A1, A0, 11, 10
};

const byte DACPIN2[8] = {
  9, 8, 7, 6, 5, 4, 3, 2
};

// --------------------------------------------------
// IR SENSOR CONNECTIONS
// --------------------------------------------------

const byte SENSOR1 = A6;  // Left IR sensor
const byte SENSOR2 = A7;  // Right IR sensor

int leftIR = 0;
int rightIR = 0;

// --------------------------------------------------
// IR SENSOR THRESHOLDS
//
// WHITE = 0 to 50
// BLACK = 500 to 1023
// Between 51 and 499 = transition region
// --------------------------------------------------

const int WHITE_THRESHOLD = 50;
const int BLACK_THRESHOLD = 500;

bool leftWhite = false;
bool rightWhite = false;

// --------------------------------------------------
// MOTOR SPEED SETTINGS
//
// 128 = Stop / Neutral
// On this robot, values ABOVE 128 drive the motors BACKWARDS,
// so FORWARD is BELOW 128.
//
// Speeds are given as an offset from neutral, and the
// direction flags below decide which side of 128 is "forward".
//   FAST: 128 - 67 = 61   (same speed as the old 195, but forward)
//   SLOW: 128 - 37 = 91   (same speed as the old 165, but forward)
//
// If ONE motor still spins the wrong way, flip only that
// motor's flag below.
// --------------------------------------------------

const byte STOP_SPEED  = 128;

// These are set from the GUI:
//   speed slider       (command 7) -> FAST_OFFSET
//   correction wheel % (command 8) -> SLOW_OFFSET
// Defaults (53 % speed, 55 % correction) = about the original
// speeds (fast 61, slow 92).
byte speedPercent = 53;
byte turnPercent  = 55;   // correction wheel speed, % of main speed
                          // 0 = that wheel STOPS while correcting

byte FAST_OFFSET = 67;
byte SLOW_OFFSET = 36;

// Recalculates both offsets from the two GUI settings.
//   speed 100 % -> fast offset 127 (full forward), 0 % -> stopped
//   correction wheel = turnPercent of the fast offset
void updateSpeeds()
{
  FAST_OFFSET = (byte)((speedPercent * 127L) / 100);
  SLOW_OFFSET = (byte)((FAST_OFFSET * (long)turnPercent) / 100);
}

void setSpeedPercent(byte percent)
{
  if (percent > 100) percent = 100;
  speedPercent = percent;
  updateSpeeds();
}

void setTurnPercent(byte percent)
{
  if (percent > 100) percent = 100;
  turnPercent = percent;
  updateSpeeds();
}

// true  = forward is BELOW 128 (128 - offset)
// false = forward is ABOVE 128 (128 + offset)
const bool LEFT_FORWARD_IS_LOW  = true;
const bool RIGHT_FORWARD_IS_LOW = true;

// --------------------------------------------------
// LINE LOST RECOVERY SETTINGS
//
// When BOTH sensors see black, the robot no longer stops
// straight away. It remembers which sensor saw the white
// line LAST and spins towards that side until a sensor
// finds the line again, then normal line following resumes.
//
// RECOVERY_OUTER_PERCENT : outer wheel forward speed, % of full speed
// RECOVERY_INNER_PERCENT : inner wheel REVERSE speed, % of full speed
//                          (0 = inner wheel stopped, robot pivots on it;
//                           same as outer = spins on the spot)
// RECOVERY_TIMEOUT_MS    : give up and stop if the line is not found
//                          in this time (safety). 0 = never give up.
// --------------------------------------------------

const byte RECOVERY_OUTER_PERCENT = 40;
const byte RECOVERY_INNER_PERCENT = 20;
const unsigned long RECOVERY_TIMEOUT_MS = 3000;

const byte SIDE_NONE  = 0;
const byte SIDE_LEFT  = 1;
const byte SIDE_RIGHT = 2;

byte lastSeenSide = SIDE_NONE;     // which sensor saw the line last
bool searching = false;            // true while turning to find the line
unsigned long searchStartTime = 0;

// DAC1 = Left motor
// DAC2 = Right motor

byte output1 = STOP_SPEED;
byte output2 = STOP_SPEED;

// --------------------------------------------------
// SERIAL COMMUNICATION VARIABLES
// --------------------------------------------------

const long BAUD_RATE = 38400;   // XBee baud rate

const byte START = 255;

const byte INPUT1 = 0;
const byte INPUT2 = 1;
const byte OUTPUT1 = 2;
const byte OUTPUT2 = 3;

const byte AUTO_MODE = 4;
const byte STOP_MODE = 5;
const byte STATUS_REQ = 6;
const byte SPEED_SET = 7;     // DATA = line following speed 0-100 %
const byte TURN_SET  = 8;     // DATA = correction wheel speed 0-100 %
                              //        (0 = wheel stops while correcting)
const byte DIR_SET   = 9;     // DATA = 0 forward, 1 reverse
const byte ALL_REQ   = 10;    // sensors + status in one reply burst
const byte LINK_REQ  = 11;    // link statistics

// Reply ports for status
const byte PORT_LEFT_MOTOR = 6;
const byte PORT_RIGHT_MOTOR = 7;
const byte PORT_MODE = 8;
const byte PORT_DIRECTION = 9;  // 0 = forward, 1 = reverse
const byte PORT_RX_GOOD   = 10; // packets received OK
const byte PORT_RX_BAD    = 11; // packets with a bad checksum
const byte PORT_RX_STRAY  = 12; // stray bytes thrown away

// Link statistics (sent to the GUI's packet inspector)
unsigned int rxGoodCount  = 0;
unsigned int rxBadCount   = 0;
unsigned int rxStrayCount = 0;

// Receive buffer for one 4-byte packet
byte rxBuf[4];
byte rxCount = 0;


// Robot starts STOPPED. Press START in the GUI to begin line following.
bool automaticMode = false;

// --------------------------------------------------
// DAC OUTPUT FUNCTION 1
// --------------------------------------------------

void outputToDAC1(byte data)
{
  for (int i = 0; i <= 7; i++)
  {
    digitalWrite(
      DACPIN1[i],
      ((data >> i) & 1) ? HIGH : LOW
    );
  }
}

// --------------------------------------------------
// DAC OUTPUT FUNCTION 2
// --------------------------------------------------

void outputToDAC2(byte data)
{
  for (int i = 0; i <= 7; i++)
  {
    digitalWrite(
      DACPIN2[i],
      ((data >> i) & 1) ? HIGH : LOW
    );
  }
}

// --------------------------------------------------
// INITIALISE DAC PINS
// --------------------------------------------------

void initDACs()
{
  for (int i = 0; i <= 7; i++)
  {
    pinMode(DACPIN1[i], OUTPUT);
    pinMode(DACPIN2[i], OUTPUT);
  }
}

// --------------------------------------------------
// SET MOTOR SPEEDS
// --------------------------------------------------

void setMotors(byte leftSpeed, byte rightSpeed)
{
  output1 = leftSpeed;
  output2 = rightSpeed;

  outputToDAC1(output1);
  outputToDAC2(output2);
}

// --------------------------------------------------
// DRIVE BOTH MOTORS FORWARD
//
// Takes forward speed offsets (0 = stop) and converts
// them to the correct DAC value for each motor's direction.
// --------------------------------------------------

byte forwardValue(byte offset, bool forwardIsLow)
{
  return forwardIsLow ? (byte)(STOP_SPEED - offset)
                      : (byte)(STOP_SPEED + offset);
}

void driveForward(byte leftOffset, byte rightOffset)
{
  setMotors(
    forwardValue(leftOffset, LEFT_FORWARD_IS_LOW),
    forwardValue(rightOffset, RIGHT_FORWARD_IS_LOW)
  );
}

// --------------------------------------------------
// DRIVE EACH MOTOR WITH A SIGNED OFFSET
//
// Positive offset = forward, negative offset = backward.
// Used by the recovery turn so the inner wheel can reverse.
// --------------------------------------------------

byte signedValue(int offset, bool forwardIsLow)
{
  if (offset > 127)  offset = 127;
  if (offset < -127) offset = -127;

  int value = forwardIsLow ? (STOP_SPEED - offset)
                           : (STOP_SPEED + offset);
  return (byte)value;
}

void driveSigned(int leftOffset, int rightOffset)
{
  setMotors(
    signedValue(leftOffset, LEFT_FORWARD_IS_LOW),
    signedValue(rightOffset, RIGHT_FORWARD_IS_LOW)
  );
}

// --------------------------------------------------
// DRIVE IN THE SELECTED DIRECTION (forward / reverse)
//
// All line following and recovery moves are written as
// if the robot drives FORWARD. In REVERSE mode the same
// move is mirrored: both wheels run backwards and the
// left/right speeds are swapped. This keeps the robot
// turning the same way (towards the line), just while
// travelling backwards.
//
//   forward: left = L,  right = R
//   reverse: left = -R, right = -L
// --------------------------------------------------

bool reverseMode = false;   // set from the GUI (command 9)

void driveDirection(int leftOffset, int rightOffset)
{
  if (reverseMode)
  {
    driveSigned(-rightOffset, -leftOffset);
  }
  else
  {
    driveSigned(leftOffset, rightOffset);
  }
}

// --------------------------------------------------
// STOP BOTH MOTORS
// --------------------------------------------------

void stopMotors()
{
  setMotors(STOP_SPEED, STOP_SPEED);
}

// --------------------------------------------------
// IR SENSOR DETECTION USING HYSTERESIS
//
// White gives LOW readings (0-50)
// Black gives HIGH readings (500+)
//
// Between thresholds, previous state is kept.
// --------------------------------------------------

bool detectWhite(int reading, bool previousState)
{
  if (reading <= WHITE_THRESHOLD)
  {
    // White surface detected
    return true;
  }
  else if (reading >= BLACK_THRESHOLD)
  {
    // Black surface detected
    return false;
  }
  else
  {
    // Reading between 51 and 499
    // Keep previous state
    return previousState;
  }
}

// --------------------------------------------------
// READ BOTH IR SENSORS
// --------------------------------------------------

void readSensors()
{
  leftIR = analogRead(SENSOR1);
  rightIR = analogRead(SENSOR2);

  leftWhite = detectWhite(leftIR, leftWhite);
  rightWhite = detectWhite(rightIR, rightWhite);
}

// --------------------------------------------------
// BANG-BANG LINE FOLLOWING CONTROL
// --------------------------------------------------

// --------------------------------------------------
// LINE LOST RECOVERY
//
// Spins towards the side where the line was last seen.
// Returns false if the search timed out (robot stopped).
// --------------------------------------------------

bool recoverLine()
{
  // Nothing remembered (line was never seen by one sensor
  // alone) - we cannot know which way to turn, so stop.
  if (lastSeenSide == SIDE_NONE)
  {
    stopMotors();
    return false;
  }

  // Start of a new search - note the time
  if (!searching)
  {
    searching = true;
    searchStartTime = millis();
  }

  // Safety timeout
  if (RECOVERY_TIMEOUT_MS > 0 &&
      millis() - searchStartTime > RECOVERY_TIMEOUT_MS)
  {
    stopMotors();
    return false;
  }

  int outer = (RECOVERY_OUTER_PERCENT * 127) / 100;
  int inner = (RECOVERY_INNER_PERCENT * 127) / 100;

  if (lastSeenSide == SIDE_LEFT)
  {
    // Line was last on the LEFT -> turn LEFT
    // Left wheel backwards (or stopped), right wheel forwards
    driveDirection(-inner, outer);
  }
  else
  {
    // Line was last on the RIGHT -> turn RIGHT
    // Left wheel forwards, right wheel backwards (or stopped)
    driveDirection(outer, -inner);
  }

  return true;
}

// --------------------------------------------------
// BANG-BANG LINE FOLLOWING CONTROL
// --------------------------------------------------

void lineFollowing()
{
  readSensors();

  // Any white seen = line found, so any search is over
  if (leftWhite || rightWhite)
  {
    searching = false;
  }

  // CASE 1: BOTH SENSORS DETECT WHITE
  // Robot is centred on white track

  if (leftWhite && rightWhite)
  {
    // Move straight
    // (lastSeenSide is kept, so if the line ends suddenly
    //  we still turn towards the side it was drifting to)
    driveDirection(FAST_OFFSET, FAST_OFFSET);
  }

  // CASE 2: LEFT WHITE, RIGHT BLACK

  else if (leftWhite && !rightWhite)
  {
    // Line is under the LEFT sensor - remember it
    lastSeenSide = SIDE_LEFT;

    // Turn LEFT
    // Left motor slow, right motor fast

    driveDirection(SLOW_OFFSET, FAST_OFFSET);
  }

  // CASE 3: LEFT BLACK, RIGHT WHITE

  else if (!leftWhite && rightWhite)
  {
    // Line is under the RIGHT sensor - remember it
    lastSeenSide = SIDE_RIGHT;

    // Turn RIGHT
    // Left motor fast, right motor slow

    driveDirection(FAST_OFFSET, SLOW_OFFSET);
  }

  // CASE 4: BOTH SENSORS DETECT BLACK

  else
  {
    // White line lost - turn towards the side it was
    // last seen on. Resumes automatically as soon as a
    // sensor sees white again (cases 1-3 above).
    // If the search times out, the robot stops and
    // leaves automatic mode.

    if (!recoverLine())
    {
      automaticMode = false;
      searching = false;
    }
  }
}

// Resets the memory when line following is (re)started
void resetRecovery()
{
  lastSeenSide = SIDE_NONE;
  searching = false;
}

// --------------------------------------------------
// SEND ONE 4-BYTE PACKET TO THE GUI (via XBee)
// --------------------------------------------------

void sendPacket(byte port, byte value)
{
  byte checksum =
    (byte)(START + port + value);

  Serial.write(START);
  Serial.write(port);
  Serial.write(value);
  Serial.write(checksum);
}

// --------------------------------------------------
// SEND SENSOR READINGS TO GUI
//
// Convert 10-bit ADC reading (0-1023)
// to an 8-bit value (0-255).
// --------------------------------------------------

void sendSensorData(byte port, int sensorValue)
{
  sendPacket(port, (byte)(sensorValue / 4));
}

// --------------------------------------------------
// SEND ROBOT STATUS (motor outputs + mode)
// --------------------------------------------------

void sendStatus()
{
  sendPacket(PORT_LEFT_MOTOR, output1);
  sendPacket(PORT_RIGHT_MOTOR, output2);
  // 0 = stopped/manual, 1 = following the line, 2 = searching for the line
  byte mode = 0;
  if (automaticMode) mode = searching ? 2 : 1;
  sendPacket(PORT_MODE, mode);
  sendPacket(PORT_DIRECTION, reverseMode ? 1 : 0);
}

// --------------------------------------------------
// HANDLE SERIAL COMMUNICATION FROM GUI
//
// Reads bytes one at a time as they arrive (no waiting for
// 4 bytes), so a packet is handled as soon as its last byte
// is in.
//
// Re-synchronisation: if a packet has a bad checksum, only
// its start byte is thrown away and the other 3 bytes are
// searched for the next 255. The old version threw all 4
// away, which also destroyed the NEXT good packet whenever
// a single byte had been lost on the radio link.
// --------------------------------------------------

void handleSerial()
{
  while (Serial.available() > 0)
  {
    byte b = Serial.read();

    // Waiting for a start byte
    if (rxCount == 0 && b != START)
    {
      rxStrayCount++;
      continue;
    }

    rxBuf[rxCount++] = b;

    if (rxCount < 4)
    {
      continue;   // packet not complete yet
    }

    // Full packet - check it
    byte sum = (byte)(rxBuf[0] + rxBuf[1] + rxBuf[2]);

    if (sum == rxBuf[3])
    {
      rxGoodCount++;
      rxCount = 0;
      processCommand(rxBuf[1], rxBuf[2]);
    }
    else
    {
      rxBadCount++;

      // Look for another start byte inside the bad packet
      byte next = 0;
      for (byte i = 1; i < 4; i++)
      {
        if (rxBuf[i] == START) { next = i; break; }
      }

      if (next == 0)
      {
        rxCount = 0;
      }
      else
      {
        rxCount = 4 - next;
        for (byte i = 0; i < rxCount; i++) rxBuf[i] = rxBuf[next + i];
      }
    }
  }
}

// --------------------------------------------------
// SEND LINK STATISTICS (low byte of each counter)
// --------------------------------------------------

void sendLinkStats()
{
  sendPacket(PORT_RX_GOOD,  (byte)(rxGoodCount  & 0xFF));
  sendPacket(PORT_RX_BAD,   (byte)(rxBadCount   & 0xFF));
  sendPacket(PORT_RX_STRAY, (byte)(rxStrayCount & 0xFF));
}

// --------------------------------------------------
// CARRY OUT ONE VALID COMMAND FROM THE GUI
// --------------------------------------------------

void processCommand(byte commandByte, byte dataByte)
{
    switch (commandByte)
    {
      // ----------------------------------------
      // INPUT 1: LEFT IR SENSOR
      // ----------------------------------------

      case INPUT1:
      {
        sendSensorData(
          INPUT1,
          analogRead(SENSOR1)
        );

        break;
      }

      // ----------------------------------------
      // INPUT 2: RIGHT IR SENSOR
      // ----------------------------------------

      case INPUT2:
      {
        sendSensorData(
          INPUT2,
          analogRead(SENSOR2)
        );

        break;
      }

      // ----------------------------------------
      // OUTPUT 1: LEFT MOTOR MANUAL CONTROL
      // ----------------------------------------

      case OUTPUT1:
      {
        automaticMode = false;

        setMotors(dataByte, output2);

        break;
      }

      // ----------------------------------------
      // OUTPUT 2: RIGHT MOTOR MANUAL CONTROL
      // ----------------------------------------

      case OUTPUT2:
      {
        automaticMode = false;

        setMotors(output1, dataByte);

        break;
      }

      // ----------------------------------------
      // START: AUTOMATIC LINE FOLLOWING
      // ----------------------------------------

      case AUTO_MODE:
      {
        resetRecovery();
        automaticMode = true;

        break;
      }

      // ----------------------------------------
      // STOP ROBOT
      // ----------------------------------------

      case STOP_MODE:
      {
        automaticMode = false;

        stopMotors();

        break;
      }

      // ----------------------------------------
      // STATUS REQUEST
      // ----------------------------------------

      case STATUS_REQ:
      {
        sendStatus();

        break;
      }

      // ----------------------------------------
      // SET LINE FOLLOWING SPEED (GUI slider)
      // Takes effect immediately, even while running.
      // ----------------------------------------

      case SPEED_SET:
      {
        setSpeedPercent(dataByte);

        break;
      }

      // ----------------------------------------
      // SET CORRECTION WHEEL SPEED (GUI input)
      // % of the main speed used by the slower
      // wheel when the robot corrects back onto
      // the line. 0 = that wheel stops.
      // ----------------------------------------

      case TURN_SET:
      {
        setTurnPercent(dataByte);

        break;
      }

      // ----------------------------------------
      // SET DRIVING DIRECTION (GUI Forward/Reverse)
      // 0 = forward, 1 = reverse.
      // Takes effect immediately, even while running.
      // The last-seen side is kept, so recovery still
      // turns towards the line after a switch.
      // ----------------------------------------

      case DIR_SET:
      {
        reverseMode = (dataByte != 0);

        break;
      }

      // ----------------------------------------
      // REQUEST ALL (sensors + status at once)
      // One small request instead of three keeps
      // the radio link much quieter.
      // ----------------------------------------

      case ALL_REQ:
      {
        sendSensorData(INPUT1, analogRead(SENSOR1));
        sendSensorData(INPUT2, analogRead(SENSOR2));
        sendStatus();

        break;
      }

      // ----------------------------------------
      // LINK STATISTICS (for the packet inspector)
      // ----------------------------------------

      case LINK_REQ:
      {
        sendLinkStats();

        break;
      }
    }
}

// --------------------------------------------------
// SETUP
// --------------------------------------------------

void setup()
{
  Serial.begin(BAUD_RATE);   // XBee on hardware serial

  initDACs();

  pinMode(SENSOR1, INPUT);
  pinMode(SENSOR2, INPUT);

  // Stop motors initially
  stopMotors();

  // Allow hardware to settle
  delay(2000);
}

// --------------------------------------------------
// MAIN LOOP
// --------------------------------------------------

void loop()
{
  // Check commands from GUI
  handleSerial();

  // Run automatic Bang-Bang control
  if (automaticMode)
  {
    lineFollowing();
  }

  // Small delay between readings
  delay(10);
}
