// Curtin University
// Mechatronics Engineering
// White Line Following Robot - LAPTOP (BRIDGE) NANO
//
// Plugged into the PC by USB. Passes every byte straight through:
//
//   GUI (USB Serial)  --->  XBee  --->  Robot
//   GUI (USB Serial)  <---  XBee  <---  Robot
//
// It does not interpret the 4-byte packets; the GUI and robot
// handle the protocol and checksums.
//
// WIRING:
//   XBee DOUT -> Nano D2 (SoftwareSerial RX)
//   XBee DIN  <- Nano D3 (SoftwareSerial TX)
//
// Baud rate: 38400 on both ports (must match XBee config, robot
//            sketch and the GUI).
//
// NOTE: Nothing else is printed to the USB serial (no "READY"
// text), because any extra text would get mixed into the binary
// sensor packets that the GUI is decoding.

#include <SoftwareSerial.h>

const long BAUD_RATE = 38400;

SoftwareSerial XBeeSerial(2, 3);   // RX, TX

void setup()
{
  Serial.begin(BAUD_RATE);       // USB to PC / GUI
  XBeeSerial.begin(BAUD_RATE);   // XBee radio
}

void loop()
{
  // Robot -> PC (sensor readings, status)
  while (XBeeSerial.available())
  {
    Serial.write(XBeeSerial.read());
  }

  // PC -> Robot (start, stop, motor commands, data requests)
  while (Serial.available())
  {
    XBeeSerial.write(Serial.read());
  }
}
