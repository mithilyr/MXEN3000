LINE FOLLOWING ROBOT - XBee + GUI
=================================

Robot_Nano/Robot_Nano.ino            -> upload to the ROBOT (PCB) Nano
Laptop_Nano_Bridge/Laptop_Nano_Bridge.ino -> upload to the Nano plugged into the laptop
GUI/  (open SerialIO_GUI_Sample_2016_4byte.sln in Visual Studio, then Start)

WIRING
  Robot Nano : XBee DOUT -> D0 (RX), XBee DIN <- D1 (TX)
               UNPLUG the XBee while uploading (D0/D1 are shared with USB).
  Laptop Nano: XBee DOUT -> D2, XBee DIN <- D3

BAUD RATE: 38400 everywhere (both XBees must be set to 38400 in XCTU).

USING THE GUI
  1. Pick the laptop Nano's COM port -> Connect.
  2. "Robot link OK" (green) = robot is replying.
  3. START = bang-bang line following.  STOP = motors to 128 (neutral).
     Speed slider (0-100 %) sets the line following speed. It can be
     moved while the robot is running (53 % = the original speed).
     Correction wheel speed (% of speed): how fast the slower wheel turns
     while steering back onto the line (default 55 %).
     Tick "Stop the correction wheel" to make that wheel stop completely
     while correcting (sharper turns).
  4. Manual Motor Control: set a value 0-255 and Send (128 = stop).
     Sending a motor value pauses line following (manual mode).
     Tick "Live control" to drive with the sliders in real time.
  5. Sensor Readings refresh automatically (Left/Right IR, WHITE/BLACK,
     motor outputs). Closing the GUI sends STOP automatically.

FORWARD / REVERSE
  The Direction option (FORWARD / REVERSE) in the Line Following panel sets
  which way the robot drives while following the line. It can be switched
  before pressing START or while running. The mode box shows the direction.
  In reverse the sensors are at the back of the travel direction, so the
  robot reacts later - start with a lower speed (about 30-40 %).
  Manual motor control is not affected by this option.

PACKET INSPECTOR + PACKET LOG FILE
  "Save packets to CSV" (Log panel, ticked by default) records every packet
  of a session to Documents\LineFollowerPacketLogs\packets_<date>_<time>.csv
  (opens in Excel). The file is closed and a summary added when you
  disconnect or close the GUI.
  "Packet Inspector..." opens a live window with every packet sent (TX) and
  received (RX), plus:
    LOST     a request got no reply within the timeout (default 500 ms)
    PARTIAL  only some of a reply's packets arrived
    BAD      a packet with a wrong checksum
    STRAY    bytes thrown away while re-synchronising
  Robot->PC loss is measured from missing replies. PC->robot loss is
  measured from the robot's own "packets received" counter (asked for once
  a second). Round-trip time (RTT) is shown for every complete reply.
  The connection label on the main window shows the loss % live.

COMMUNICATION CHANGES
  - The GUI now asks for everything with ONE request (command 10) instead of
    three, every 200 ms. Half the PC->robot traffic, fresher readings.
  - The robot reads packets byte by byte and, after a bad packet, only drops
    the start byte, so one lost radio byte no longer also kills the next
    good packet.
  The robot code and GUI must both be updated (old robot code does not
  answer command 10, so every request would show as LOST).

LINE LOST RECOVERY
  If both sensors see black, the robot no longer stops. It remembers which
  sensor saw the white line last and turns towards that side until the line
  is found, then line following carries on. The GUI shows
  "SEARCHING FOR LINE" (yellow) while it does this. If the line is not found
  within 3 s, the robot stops (press START again).
  Tune RECOVERY_OUTER_PERCENT / RECOVERY_INNER_PERCENT / RECOVERY_TIMEOUT_MS
  near the top of Robot_Nano.ino.

The robot now boots STOPPED - it only starts line following when you press START.
