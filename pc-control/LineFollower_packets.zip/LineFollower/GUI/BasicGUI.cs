﻿// Curtin University
// Mechatronics Engineering
// White Line Following Robot - PC Control GUI
//
// Talks to the LAPTOP (bridge) Nano over USB serial at 38400 baud.
// The bridge Nano forwards everything to the robot over XBee.
//
// 4-byte protocol: [255][PORT/COMMAND][DATA][CHECKSUM]
//   CHECKSUM = (255 + PORT + DATA) mod 256
//
//   GUI -> Robot                     Robot -> GUI
//   0 = request Left IR              0 = Left IR value  (0-255)
//   1 = request Right IR             1 = Right IR value (0-255)
//   2 = Left motor  = DATA           6 = Left motor output
//   3 = Right motor = DATA           7 = Right motor output
//   4 = START line following         8 = Mode (1 = running auto)
//   5 = STOP
//   6 = request status (6, 7, 8, 9)
//   7 = set line-following speed = DATA (0-100 %)
//   8 = set correction wheel speed = DATA (0-100 % of speed, 0 = stop)
//   9 = set direction = DATA (0 = forward, 1 = reverse)
//                                    9 = Direction (0 = fwd, 1 = rev)
//  10 = request ALL (0,1,6,7,8,9)   10/11/12 = robot link counters
//  11 = request link statistics

using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;

namespace SerialGUISample
{
    public partial class Form1 : Form
    {
        // ------------------------------------------------------------
        // PROTOCOL CONSTANTS (must match Robot_Nano.ino)
        // ------------------------------------------------------------
        const int BAUD_RATE = 38400;

        const byte START = 255;
        const byte ZERO = 0;

        const byte CMD_INPUT1 = 0;      // Left IR
        const byte CMD_INPUT2 = 1;      // Right IR
        const byte CMD_OUTPUT1 = 2;     // Left motor
        const byte CMD_OUTPUT2 = 3;     // Right motor
        const byte CMD_AUTO = 4;        // Start line following
        const byte CMD_STOP = 5;        // Stop
        const byte CMD_STATUS = 6;      // Request motor outputs + mode
        const byte CMD_SPEED = 7;       // Set line-following speed (0-100 %)
        const byte CMD_TURN = 8;        // Set correction wheel speed (0-100 %, 0 = stop)
        const byte CMD_DIRECTION = 9;   // Set direction (0 = forward, 1 = reverse)
        const byte CMD_ALL = 10;        // Request sensors + status in one go
        const byte CMD_LINK = 11;       // Request robot link statistics

        const byte PORT_LEFT_MOTOR = 6;
        const byte PORT_RIGHT_MOTOR = 7;
        const byte PORT_MODE = 8;
        const byte PORT_DIRECTION = 9;

        const byte NEUTRAL = 128;       // Motor stop / neutral value

        // IR thresholds from the robot code (10-bit), converted to the
        // 8-bit values the robot sends (10-bit / 4).
        const int WHITE_THRESHOLD_8BIT = 50 / 4;    // <= 12  -> WHITE
        const int BLACK_THRESHOLD_8BIT = 500 / 4;   // >= 125 -> BLACK

        // ------------------------------------------------------------
        // STATE
        // ------------------------------------------------------------
        byte[] Outputs = new byte[4];
        List<byte> rxBuffer = new List<byte>();

        // Packet monitor (counts sent / received / lost packets and
        // records them to CSV) + its window
        PacketMonitor monitor = new PacketMonitor();
        PacketInspectorForm inspector;
        DateTime lastLinkPoll = DateTime.MinValue;
        const int LINK_POLL_MS = 1000;
        DateTime lastRx = DateTime.MinValue;

        byte lastSentLeft = NEUTRAL;
        byte lastSentRight = NEUTRAL;
        bool updatingControls = false;

        // Speed slider: -1 forces a send on the next timer tick
        int lastSentSpeed = -1;
        int lastSentTurn = -1;
        int lastSentDirection = -1;

        // Last values reported by the robot (for the mode label)
        byte robotMode = 0;
        bool robotReverse = false;

        public Form1()
        {
            InitializeComponent();

            serial.BaudRate = BAUD_RATE;
            RefreshPorts();
            SetConnectedUI(false);
            SetMotorControls(NEUTRAL, NEUTRAL);
        }

        // ============================================================
        // CONNECTION
        // ============================================================

        private void RefreshPorts()
        {
            string current = cmbPort.Text;
            cmbPort.Items.Clear();
            string[] ports = SerialPort.GetPortNames();
            Array.Sort(ports);
            cmbPort.Items.AddRange(ports);

            if (current != "" && cmbPort.Items.Contains(current))
                cmbPort.Text = current;
            else if (cmbPort.Items.Count > 0)
                cmbPort.SelectedIndex = cmbPort.Items.Count - 1;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshPorts();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (serial.IsOpen)
            {
                Disconnect();
                return;
            }

            if (cmbPort.Text == "")
            {
                Log("Select a COM port first.");
                return;
            }

            try
            {
                serial.PortName = cmbPort.Text;
                serial.BaudRate = BAUD_RATE;
                serial.Open();
                serial.DiscardInBuffer();
                rxBuffer.Clear();
                lastRx = DateTime.MinValue;
                lastSentSpeed = -1;     // send the slider speed straight away
                lastSentTurn = -1;      // and the correction wheel setting
                lastSentDirection = -1; // and the direction
                monitor.Reset();
                lastLinkPoll = DateTime.MinValue;
                SetConnectedUI(true);
                Log("Connected to " + serial.PortName + " @ " + BAUD_RATE);
                StartRecordingIfWanted();
            }
            catch (Exception ex)
            {
                SetConnectedUI(false);
                Log("ERROR: Failed to connect - " + ex.Message);
            }
        }

        private void Disconnect()
        {
            try
            {
                if (serial.IsOpen)
                {
                    // safety: stop robot first (written directly so a
                    // write error here cannot call Disconnect again)
                    byte[] stop = { START, CMD_STOP, ZERO, unchecked((byte)(START + CMD_STOP + ZERO)) };
                    serial.Write(stop, 0, 4);
                    monitor.Sent(CMD_STOP, ZERO);
                    System.Threading.Thread.Sleep(50);
                    serial.Close();
                }
            }
            catch { }

            if (monitor.Recording)
            {
                string path = monitor.RecordPath;
                monitor.StopRecording();
                Log("Packet log saved: " + path);
            }
            foreach (string line in monitor.SummaryLines()) Log(line);

            SetConnectedUI(false);
            Log("Disconnected.");
        }

        private void SetConnectedUI(bool connected)
        {
            btnConnect.Text = connected ? "Disconnect" : "Connect";
            cmbPort.Enabled = !connected;
            btnRefresh.Enabled = !connected;
            grpRobot.Enabled = connected;
            grpMotors.Enabled = connected;
            grpSensors.Enabled = connected;
            lblConnStatus.Text = connected ? "Port open" : "Not connected";
            lblConnStatus.ForeColor = connected ? Color.DarkOrange : Color.Gray;

            if (!connected)
            {
                lblMode.Text = "UNKNOWN";
                lblMode.BackColor = Color.LightGray;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Disconnect();
        }

        // ============================================================
        // SEND A 4-BYTE MESSAGE (same format as the sample GUI)
        // ============================================================

        private void sendIO(byte PORT, byte DATA)
        {
            Outputs[0] = START;
            Outputs[1] = PORT;
            Outputs[2] = DATA;
            Outputs[3] = (byte)(START + PORT + DATA);

            if (serial.IsOpen)
            {
                try
                {
                    serial.Write(Outputs, 0, 4);
                    monitor.Sent(PORT, DATA);
                }
                catch (Exception ex)
                {
                    Log("ERROR: Write failed - " + ex.Message);
                    Disconnect();
                }
            }
        }

        // ============================================================
        // START / STOP
        // ============================================================

        private void btnStart_Click(object sender, EventArgs e)
        {
            SendSpeed();                // make sure the robot has the current speed
            SendTurn();                 // and the current correction setting
            SendDirection();            // and the current direction
            sendIO(CMD_AUTO, ZERO);
            Log("START sent (automatic line following) " + DirectionText() + " at "
                + trkSpeed.Value + " % speed, correction wheel " + TurnSettingText() + ".");
        }

        // ============================================================
        // CORRECTION WHEEL SPEED
        // When the robot drifts off the line, one wheel slows down to
        // steer it back. This sets that wheel's speed as a % of the
        // main speed. "Stop the correction wheel" sends 0 (wheel stops).
        // ============================================================

        private int CurrentTurnPercent()
        {
            return chkStopWheel.Checked ? 0 : (int)numTurn.Value;
        }

        private string TurnSettingText()
        {
            return chkStopWheel.Checked ? "STOPPED" : numTurn.Value + " %";
        }

        private void SendTurn()
        {
            lastSentTurn = CurrentTurnPercent();
            sendIO(CMD_TURN, (byte)lastSentTurn);
        }

        private void chkStopWheel_CheckedChanged(object sender, EventArgs e)
        {
            // number box is ignored while the wheel is set to stop
            numTurn.Enabled = !chkStopWheel.Checked;
        }

        // ============================================================
        // DRIVING DIRECTION (FORWARD / REVERSE)
        // REVERSE makes the robot follow the line while driving
        // backwards. It can be changed while the robot is running.
        // The actual send happens in liveTimer_Tick.
        // ============================================================

        private int CurrentDirection()
        {
            return rdoReverse.Checked ? 1 : 0;
        }

        private string DirectionText()
        {
            return rdoReverse.Checked ? "REVERSE" : "FORWARD";
        }

        private void SendDirection()
        {
            lastSentDirection = CurrentDirection();
            sendIO(CMD_DIRECTION, (byte)lastSentDirection);
        }

        private void rdoDirection_CheckedChanged(object sender, EventArgs e)
        {
            // both radio buttons fire this event - only react once
            RadioButton rb = sender as RadioButton;
            if (rb == null || !rb.Checked) return;

            if (serial.IsOpen)
            {
                SendDirection();
                Log("Direction = " + DirectionText());
            }
        }

        // ============================================================
        // LINE FOLLOWING SPEED SLIDER
        // The robot uses this speed for START / bang-bang mode.
        // It can be changed while the robot is running.
        // ============================================================

        private void SendSpeed()
        {
            lastSentSpeed = trkSpeed.Value;
            sendIO(CMD_SPEED, (byte)lastSentSpeed);
        }

        private void trkSpeed_Scroll(object sender, EventArgs e)
        {
            lblSpeedValue.Text = trkSpeed.Value + " %";
            // the actual send happens in liveTimer_Tick (max every 100 ms)
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            sendIO(CMD_STOP, ZERO);
            chkLiveSend.Checked = false;
            SetMotorControls(NEUTRAL, NEUTRAL);
            lastSentLeft = NEUTRAL;
            lastSentRight = NEUTRAL;
            Log("STOP sent.");
        }

        // ============================================================
        // MANUAL MOTOR CONTROL
        // ============================================================

        private void SetMotorControls(byte left, byte right)
        {
            updatingControls = true;
            trkLeft.Value = left;
            numLeft.Value = left;
            trkRight.Value = right;
            numRight.Value = right;
            updatingControls = false;
        }

        private void trkLeft_Scroll(object sender, EventArgs e)
        {
            if (!updatingControls) numLeft.Value = trkLeft.Value;
        }

        private void trkRight_Scroll(object sender, EventArgs e)
        {
            if (!updatingControls) numRight.Value = trkRight.Value;
        }

        private void numLeft_ValueChanged(object sender, EventArgs e)
        {
            if (!updatingControls) trkLeft.Value = (int)numLeft.Value;
        }

        private void numRight_ValueChanged(object sender, EventArgs e)
        {
            if (!updatingControls) trkRight.Value = (int)numRight.Value;
        }

        private void SendLeft()
        {
            lastSentLeft = (byte)numLeft.Value;
            sendIO(CMD_OUTPUT1, lastSentLeft);
        }

        private void SendRight()
        {
            lastSentRight = (byte)numRight.Value;
            sendIO(CMD_OUTPUT2, lastSentRight);
        }

        private void btnSendLeft_Click(object sender, EventArgs e)
        {
            SendLeft();
            Log("Left motor = " + lastSentLeft + " (manual mode)");
        }

        private void btnSendRight_Click(object sender, EventArgs e)
        {
            SendRight();
            Log("Right motor = " + lastSentRight + " (manual mode)");
        }

        private void btnSendBoth_Click(object sender, EventArgs e)
        {
            SendLeft();
            SendRight();
            Log("Motors L=" + lastSentLeft + " R=" + lastSentRight + " (manual mode)");
        }

        private void btnNeutral_Click(object sender, EventArgs e)
        {
            SetMotorControls(NEUTRAL, NEUTRAL);
            SendLeft();
            SendRight();
            Log("Motors set to neutral (128).");
        }

        // Live mode: sends the slider values whenever they change,
        // at most every 100 ms so the XBee link is not flooded.
        private void liveTimer_Tick(object sender, EventArgs e)
        {
            if (!serial.IsOpen) return;

            // Speed slider changed -> send it (does not affect manual mode)
            if (trkSpeed.Value != lastSentSpeed)
            {
                SendSpeed();
                Log("Line following speed = " + lastSentSpeed + " %");
            }

            // Correction wheel setting changed -> send it
            if (CurrentTurnPercent() != lastSentTurn)
            {
                SendTurn();
                Log("Correction wheel = " + TurnSettingText());
            }

            // Direction not yet sent (e.g. just connected) -> send it
            if (CurrentDirection() != lastSentDirection)
            {
                SendDirection();
            }

            if (!chkLiveSend.Checked) return;

            if ((byte)numLeft.Value != lastSentLeft) SendLeft();
            if ((byte)numRight.Value != lastSentRight) SendRight();
        }

        private void chkLiveSend_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLiveSend.Checked)
            {
                // force an immediate send of the current slider values
                lastSentLeft = (byte)~(byte)numLeft.Value;
                lastSentRight = (byte)~(byte)numRight.Value;
                Log("Live motor control ON - robot is in manual mode.");
            }
        }

        // ============================================================
        // SENSOR POLLING
        // Requests Left IR, Right IR and Status in turn.
        // ============================================================

        private void pollTimer_Tick(object sender, EventArgs e)
        {
            if (!serial.IsOpen) return;

            if (chkAutoPoll.Checked)
            {
                // ONE request returns both sensors + motors + mode + direction.
                // (Previously 3 separate requests were sent in turn.)
                sendIO(CMD_ALL, ZERO);

                // Robot's link counters, once a second, for the packet inspector
                if ((DateTime.Now - lastLinkPoll).TotalMilliseconds >= LINK_POLL_MS)
                {
                    lastLinkPoll = DateTime.Now;
                    sendIO(CMD_LINK, ZERO);
                }
            }

            // Link indicator
            if (lastRx == DateTime.MinValue)
            {
                lblConnStatus.Text = "Port open - waiting for robot";
                lblConnStatus.ForeColor = Color.DarkOrange;
            }
            else if ((DateTime.Now - lastRx).TotalMilliseconds > 1500)
            {
                lblConnStatus.Text = "No reply from robot";
                lblConnStatus.ForeColor = Color.Red;
            }
            else
            {
                lblConnStatus.Text = "Robot link OK  (" + monitor.ShortStatus() + ")";
                lblConnStatus.ForeColor = Color.Green;
            }
        }

        private void btnReadNow_Click(object sender, EventArgs e)
        {
            sendIO(CMD_ALL, ZERO);
        }

        private void numPollRate_ValueChanged(object sender, EventArgs e)
        {
            pollTimer.Interval = (int)numPollRate.Value;
        }

        // ============================================================
        // RECEIVE
        // Reads all available bytes, then extracts every valid packet.
        // If the checksum fails the buffer slides forward one byte,
        // so the GUI re-synchronises after a lost/corrupted byte.
        // ============================================================

        private void getIOtimer_Tick(object sender, EventArgs e)
        {
            if (!serial.IsOpen) return;

            try
            {
                int n = serial.BytesToRead;
                if (n > 0)
                {
                    byte[] buf = new byte[n];
                    int read = serial.Read(buf, 0, n);
                    for (int i = 0; i < read; i++) rxBuffer.Add(buf[i]);
                }
            }
            catch (Exception ex)
            {
                Log("ERROR: Read failed - " + ex.Message);
                Disconnect();
                return;
            }

            int stray = 0;

            while (rxBuffer.Count >= 4)
            {
                if (rxBuffer[0] != START)
                {
                    rxBuffer.RemoveAt(0);
                    stray++;
                    continue;
                }

                byte port = rxBuffer[1];
                byte data = rxBuffer[2];
                byte check = rxBuffer[3];

                if ((byte)(START + port + data) != check)
                {
                    monitor.Stray(stray);
                    stray = 0;
                    monitor.BadPacket(rxBuffer.GetRange(0, 4).ToArray());
                    rxBuffer.RemoveAt(0);   // bad packet, resync
                    continue;
                }

                monitor.Stray(stray);
                stray = 0;
                rxBuffer.RemoveRange(0, 4);
                monitor.Received(port, data);
                HandlePacket(port, data);
            }

            monitor.Stray(stray);

            // keep the buffer from growing if garbage arrives
            if (rxBuffer.Count > 256)
            {
                monitor.Stray(rxBuffer.Count);
                rxBuffer.Clear();
            }

            // find replies that never came back, flush the CSV file
            monitor.Tick();
        }

        private void HandlePacket(byte port, byte data)
        {
            lastRx = DateTime.Now;

            switch (port)
            {
                case CMD_INPUT1:
                    ShowSensor(data, lblLeftValue, prgLeft, lblLeftSurface);
                    break;

                case CMD_INPUT2:
                    ShowSensor(data, lblRightValue, prgRight, lblRightSurface);
                    break;

                case PORT_LEFT_MOTOR:
                    lblLeftMotorOut.Text = data.ToString();
                    break;

                case PORT_RIGHT_MOTOR:
                    lblRightMotorOut.Text = data.ToString();
                    break;

                case PORT_MODE:
                    robotMode = data;
                    ShowMode();
                    break;

                case PORT_DIRECTION:
                    robotReverse = (data != 0);
                    ShowMode();
                    break;
            }
        }

        private void ShowMode()
        {
            string dir = robotReverse ? " - REVERSE" : " - FORWARD";

            if (robotMode == 1)
            {
                lblMode.Text = "RUNNING (AUTO)" + dir;
                lblMode.BackColor = Color.LightGreen;
            }
            else if (robotMode == 2)
            {
                lblMode.Text = "SEARCHING FOR LINE" + dir;
                lblMode.BackColor = Color.Khaki;
            }
            else
            {
                lblMode.Text = "STOPPED / MANUAL";
                lblMode.BackColor = Color.LightSalmon;
            }
        }

        private void ShowSensor(byte value, Label valueLabel, ProgressBar bar, Label surfaceLabel)
        {
            valueLabel.Text = value.ToString() + "   (~" + (value * 4).ToString() + " / 1023)";
            bar.Value = value;

            if (value <= WHITE_THRESHOLD_8BIT)
            {
                surfaceLabel.Text = "WHITE";
                surfaceLabel.BackColor = Color.White;
                surfaceLabel.ForeColor = Color.Black;
            }
            else if (value >= BLACK_THRESHOLD_8BIT)
            {
                surfaceLabel.Text = "BLACK";
                surfaceLabel.BackColor = Color.Black;
                surfaceLabel.ForeColor = Color.White;
            }
            else
            {
                surfaceLabel.Text = "TRANSITION";
                surfaceLabel.BackColor = Color.Silver;
                surfaceLabel.ForeColor = Color.Black;
            }
        }

        // ============================================================
        // PACKET INSPECTOR + CSV RECORDING
        // ============================================================

        private void StartRecordingIfWanted()
        {
            if (!chkRecord.Checked || !serial.IsOpen) return;
            try
            {
                string path = monitor.StartRecording();
                Log("Recording packets to " + path);
            }
            catch (Exception ex)
            {
                Log("ERROR: Could not create packet log - " + ex.Message);
            }
        }

        private void chkRecord_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRecord.Checked)
            {
                if (!monitor.Recording) StartRecordingIfWanted();
            }
            else if (monitor.Recording)
            {
                string path = monitor.RecordPath;
                monitor.StopRecording();
                Log("Packet log saved: " + path);
            }
        }

        private void btnInspector_Click(object sender, EventArgs e)
        {
            if (inspector == null || inspector.IsDisposed)
            {
                inspector = new PacketInspectorForm(monitor);
                inspector.Show(this);
            }
            else
            {
                inspector.WindowState = FormWindowState.Normal;
                inspector.BringToFront();
            }
        }

        // ============================================================
        // LOG
        // ============================================================

        private void Log(string msg)
        {
            lstLog.Items.Add(DateTime.Now.ToString("HH:mm:ss") + "  " + msg);
            if (lstLog.Items.Count > 200) lstLog.Items.RemoveAt(0);
            lstLog.TopIndex = lstLog.Items.Count - 1;
        }
    }
}
