﻿namespace SerialGUISample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serial = new System.IO.Ports.SerialPort(this.components);
            this.getIOtimer = new System.Windows.Forms.Timer(this.components);
            this.pollTimer = new System.Windows.Forms.Timer(this.components);
            this.liveTimer = new System.Windows.Forms.Timer(this.components);

            this.grpConnection = new System.Windows.Forms.GroupBox();
            this.lblPort = new System.Windows.Forms.Label();
            this.cmbPort = new System.Windows.Forms.ComboBox();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.lblConnStatus = new System.Windows.Forms.Label();

            this.grpRobot = new System.Windows.Forms.GroupBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.lblModeTitle = new System.Windows.Forms.Label();
            this.lblMode = new System.Windows.Forms.Label();
            this.lblSpeedTitle = new System.Windows.Forms.Label();
            this.trkSpeed = new System.Windows.Forms.TrackBar();
            this.lblSpeedValue = new System.Windows.Forms.Label();
            this.lblTurnTitle = new System.Windows.Forms.Label();
            this.numTurn = new System.Windows.Forms.NumericUpDown();
            this.chkStopWheel = new System.Windows.Forms.CheckBox();
            this.chkRecord = new System.Windows.Forms.CheckBox();
            this.btnInspector = new System.Windows.Forms.Button();
            this.lblDirTitle = new System.Windows.Forms.Label();
            this.rdoForward = new System.Windows.Forms.RadioButton();
            this.rdoReverse = new System.Windows.Forms.RadioButton();

            this.grpMotors = new System.Windows.Forms.GroupBox();
            this.lblLeftMotor = new System.Windows.Forms.Label();
            this.trkLeft = new System.Windows.Forms.TrackBar();
            this.numLeft = new System.Windows.Forms.NumericUpDown();
            this.btnSendLeft = new System.Windows.Forms.Button();
            this.lblRightMotor = new System.Windows.Forms.Label();
            this.trkRight = new System.Windows.Forms.TrackBar();
            this.numRight = new System.Windows.Forms.NumericUpDown();
            this.btnSendRight = new System.Windows.Forms.Button();
            this.btnSendBoth = new System.Windows.Forms.Button();
            this.btnNeutral = new System.Windows.Forms.Button();
            this.chkLiveSend = new System.Windows.Forms.CheckBox();
            this.lblMotorHint = new System.Windows.Forms.Label();

            this.grpSensors = new System.Windows.Forms.GroupBox();
            this.lblLeftIRTitle = new System.Windows.Forms.Label();
            this.lblLeftValue = new System.Windows.Forms.Label();
            this.prgLeft = new System.Windows.Forms.ProgressBar();
            this.lblLeftSurface = new System.Windows.Forms.Label();
            this.lblRightIRTitle = new System.Windows.Forms.Label();
            this.lblRightValue = new System.Windows.Forms.Label();
            this.prgRight = new System.Windows.Forms.ProgressBar();
            this.lblRightSurface = new System.Windows.Forms.Label();
            this.lblLeftMotorOutTitle = new System.Windows.Forms.Label();
            this.lblLeftMotorOut = new System.Windows.Forms.Label();
            this.lblRightMotorOutTitle = new System.Windows.Forms.Label();
            this.lblRightMotorOut = new System.Windows.Forms.Label();
            this.chkAutoPoll = new System.Windows.Forms.CheckBox();
            this.lblPollRate = new System.Windows.Forms.Label();
            this.numPollRate = new System.Windows.Forms.NumericUpDown();
            this.btnReadNow = new System.Windows.Forms.Button();

            this.grpLog = new System.Windows.Forms.GroupBox();
            this.lstLog = new System.Windows.Forms.ListBox();

            this.grpConnection.SuspendLayout();
            this.grpRobot.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTurn)).BeginInit();
            this.grpMotors.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRight)).BeginInit();
            this.grpSensors.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPollRate)).BeginInit();
            this.grpLog.SuspendLayout();
            this.SuspendLayout();
            //
            // serial
            //
            this.serial.BaudRate = 38400;
            this.serial.PortName = "COM4";
            //
            // getIOtimer  (receive)
            //
            this.getIOtimer.Enabled = true;
            this.getIOtimer.Interval = 10;
            this.getIOtimer.Tick += new System.EventHandler(this.getIOtimer_Tick);
            //
            // pollTimer  (sensor requests)
            //
            this.pollTimer.Enabled = true;
            this.pollTimer.Interval = 200;
            this.pollTimer.Tick += new System.EventHandler(this.pollTimer_Tick);
            //
            // liveTimer  (live motor sending)
            //
            this.liveTimer.Enabled = true;
            this.liveTimer.Interval = 100;
            this.liveTimer.Tick += new System.EventHandler(this.liveTimer_Tick);

            // ======================= CONNECTION =======================
            this.grpConnection.Controls.Add(this.lblPort);
            this.grpConnection.Controls.Add(this.cmbPort);
            this.grpConnection.Controls.Add(this.btnRefresh);
            this.grpConnection.Controls.Add(this.btnConnect);
            this.grpConnection.Controls.Add(this.lblConnStatus);
            this.grpConnection.Location = new System.Drawing.Point(12, 12);
            this.grpConnection.Name = "grpConnection";
            this.grpConnection.Size = new System.Drawing.Size(340, 85);
            this.grpConnection.TabIndex = 0;
            this.grpConnection.TabStop = false;
            this.grpConnection.Text = "Connection (Laptop Nano, 38400 baud)";

            this.lblPort.AutoSize = true;
            this.lblPort.Location = new System.Drawing.Point(10, 25);
            this.lblPort.Name = "lblPort";
            this.lblPort.Text = "COM port:";

            this.cmbPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPort.Location = new System.Drawing.Point(75, 21);
            this.cmbPort.Name = "cmbPort";
            this.cmbPort.Size = new System.Drawing.Size(85, 21);
            this.cmbPort.TabIndex = 0;

            this.btnRefresh.Location = new System.Drawing.Point(166, 20);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(70, 23);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);

            this.btnConnect.Location = new System.Drawing.Point(242, 20);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(88, 23);
            this.btnConnect.TabIndex = 2;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);

            this.lblConnStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblConnStatus.Location = new System.Drawing.Point(10, 55);
            this.lblConnStatus.Name = "lblConnStatus";
            this.lblConnStatus.Size = new System.Drawing.Size(320, 20);
            this.lblConnStatus.Text = "Not connected";

            // ======================= ROBOT START / STOP =======================
            this.grpRobot.Controls.Add(this.btnStart);
            this.grpRobot.Controls.Add(this.btnStop);
            this.grpRobot.Controls.Add(this.lblModeTitle);
            this.grpRobot.Controls.Add(this.lblMode);
            this.grpRobot.Controls.Add(this.lblSpeedTitle);
            this.grpRobot.Controls.Add(this.trkSpeed);
            this.grpRobot.Controls.Add(this.lblSpeedValue);
            this.grpRobot.Controls.Add(this.lblTurnTitle);
            this.grpRobot.Controls.Add(this.numTurn);
            this.grpRobot.Controls.Add(this.chkStopWheel);
            this.grpRobot.Controls.Add(this.lblDirTitle);
            this.grpRobot.Controls.Add(this.rdoForward);
            this.grpRobot.Controls.Add(this.rdoReverse);
            this.grpRobot.Location = new System.Drawing.Point(12, 103);
            this.grpRobot.Name = "grpRobot";
            this.grpRobot.Size = new System.Drawing.Size(340, 250);
            this.grpRobot.TabIndex = 1;
            this.grpRobot.TabStop = false;
            this.grpRobot.Text = "Robot - Line Following";

            this.btnStart.BackColor = System.Drawing.Color.FromArgb(76, 175, 80);
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.btnStart.ForeColor = System.Drawing.Color.White;
            this.btnStart.Location = new System.Drawing.Point(10, 22);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(155, 50);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);

            this.btnStop.BackColor = System.Drawing.Color.FromArgb(220, 53, 69);
            this.btnStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.btnStop.ForeColor = System.Drawing.Color.White;
            this.btnStop.Location = new System.Drawing.Point(175, 22);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(155, 50);
            this.btnStop.TabIndex = 1;
            this.btnStop.Text = "STOP";
            this.btnStop.UseVisualStyleBackColor = false;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);

            this.lblModeTitle.AutoSize = true;
            this.lblModeTitle.Location = new System.Drawing.Point(10, 85);
            this.lblModeTitle.Name = "lblModeTitle";
            this.lblModeTitle.Text = "Robot mode:";

            this.lblMode.BackColor = System.Drawing.Color.LightGray;
            this.lblMode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblMode.Location = new System.Drawing.Point(90, 81);
            this.lblMode.Name = "lblMode";
            this.lblMode.Size = new System.Drawing.Size(240, 22);
            this.lblMode.Text = "UNKNOWN";
            this.lblMode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // speed slider (line following speed, 0-100 %)
            //
            this.lblSpeedTitle.AutoSize = true;
            this.lblSpeedTitle.Location = new System.Drawing.Point(10, 118);
            this.lblSpeedTitle.Name = "lblSpeedTitle";
            this.lblSpeedTitle.Text = "Speed:";

            this.trkSpeed.LargeChange = 10;
            this.trkSpeed.Location = new System.Drawing.Point(84, 112);
            this.trkSpeed.Maximum = 100;
            this.trkSpeed.Minimum = 0;
            this.trkSpeed.Name = "trkSpeed";
            this.trkSpeed.Size = new System.Drawing.Size(180, 45);
            this.trkSpeed.SmallChange = 1;
            this.trkSpeed.TabIndex = 2;
            this.trkSpeed.TickFrequency = 10;
            this.trkSpeed.Value = 53;
            this.trkSpeed.Scroll += new System.EventHandler(this.trkSpeed_Scroll);

            this.lblSpeedValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSpeedValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblSpeedValue.Location = new System.Drawing.Point(270, 114);
            this.lblSpeedValue.Name = "lblSpeedValue";
            this.lblSpeedValue.Size = new System.Drawing.Size(60, 22);
            this.lblSpeedValue.Text = "53 %";
            this.lblSpeedValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // correction wheel speed (% of speed) + stop-wheel option
            //
            this.lblTurnTitle.AutoSize = true;
            this.lblTurnTitle.Location = new System.Drawing.Point(10, 165);
            this.lblTurnTitle.Name = "lblTurnTitle";
            this.lblTurnTitle.Text = "Correction wheel speed (% of speed):";

            this.numTurn.Location = new System.Drawing.Point(270, 162);
            this.numTurn.Maximum = new decimal(new int[] { 100, 0, 0, 0 });
            this.numTurn.Minimum = new decimal(new int[] { 0, 0, 0, 0 });
            this.numTurn.Name = "numTurn";
            this.numTurn.Size = new System.Drawing.Size(60, 20);
            this.numTurn.TabIndex = 3;
            this.numTurn.Value = new decimal(new int[] { 55, 0, 0, 0 });

            this.chkStopWheel.AutoSize = true;
            this.chkStopWheel.Location = new System.Drawing.Point(13, 192);
            this.chkStopWheel.Name = "chkStopWheel";
            this.chkStopWheel.TabIndex = 4;
            this.chkStopWheel.Text = "Stop the correction wheel when off track";
            this.chkStopWheel.UseVisualStyleBackColor = true;
            this.chkStopWheel.CheckedChanged += new System.EventHandler(this.chkStopWheel_CheckedChanged);
            //
            // driving direction (forward / reverse)
            //
            this.lblDirTitle.AutoSize = true;
            this.lblDirTitle.Location = new System.Drawing.Point(10, 223);
            this.lblDirTitle.Name = "lblDirTitle";
            this.lblDirTitle.Text = "Direction:";

            this.rdoForward.AutoSize = true;
            this.rdoForward.Checked = true;
            this.rdoForward.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.rdoForward.Location = new System.Drawing.Point(90, 221);
            this.rdoForward.Name = "rdoForward";
            this.rdoForward.TabIndex = 5;
            this.rdoForward.TabStop = true;
            this.rdoForward.Text = "FORWARD";
            this.rdoForward.UseVisualStyleBackColor = true;
            this.rdoForward.CheckedChanged += new System.EventHandler(this.rdoDirection_CheckedChanged);

            this.rdoReverse.AutoSize = true;
            this.rdoReverse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.rdoReverse.Location = new System.Drawing.Point(200, 221);
            this.rdoReverse.Name = "rdoReverse";
            this.rdoReverse.TabIndex = 6;
            this.rdoReverse.Text = "REVERSE";
            this.rdoReverse.UseVisualStyleBackColor = true;
            this.rdoReverse.CheckedChanged += new System.EventHandler(this.rdoDirection_CheckedChanged);

            // ======================= MANUAL MOTORS =======================
            this.grpMotors.Controls.Add(this.lblLeftMotor);
            this.grpMotors.Controls.Add(this.trkLeft);
            this.grpMotors.Controls.Add(this.numLeft);
            this.grpMotors.Controls.Add(this.btnSendLeft);
            this.grpMotors.Controls.Add(this.lblRightMotor);
            this.grpMotors.Controls.Add(this.trkRight);
            this.grpMotors.Controls.Add(this.numRight);
            this.grpMotors.Controls.Add(this.btnSendRight);
            this.grpMotors.Controls.Add(this.btnSendBoth);
            this.grpMotors.Controls.Add(this.btnNeutral);
            this.grpMotors.Controls.Add(this.chkLiveSend);
            this.grpMotors.Controls.Add(this.lblMotorHint);
            this.grpMotors.Location = new System.Drawing.Point(12, 359);
            this.grpMotors.Name = "grpMotors";
            this.grpMotors.Size = new System.Drawing.Size(340, 250);
            this.grpMotors.TabIndex = 2;
            this.grpMotors.TabStop = false;
            this.grpMotors.Text = "Manual Motor Control";

            this.lblLeftMotor.AutoSize = true;
            this.lblLeftMotor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblLeftMotor.Location = new System.Drawing.Point(10, 22);
            this.lblLeftMotor.Name = "lblLeftMotor";
            this.lblLeftMotor.Text = "Left motor (DAC1)";

            this.trkLeft.LargeChange = 10;
            this.trkLeft.Location = new System.Drawing.Point(6, 40);
            this.trkLeft.Maximum = 255;
            this.trkLeft.Name = "trkLeft";
            this.trkLeft.Size = new System.Drawing.Size(180, 45);
            this.trkLeft.TabIndex = 0;
            this.trkLeft.TickFrequency = 32;
            this.trkLeft.Value = 128;
            this.trkLeft.Scroll += new System.EventHandler(this.trkLeft_Scroll);

            this.numLeft.Location = new System.Drawing.Point(192, 42);
            this.numLeft.Maximum = new decimal(new int[] { 255, 0, 0, 0 });
            this.numLeft.Name = "numLeft";
            this.numLeft.Size = new System.Drawing.Size(55, 20);
            this.numLeft.TabIndex = 1;
            this.numLeft.Value = new decimal(new int[] { 128, 0, 0, 0 });
            this.numLeft.ValueChanged += new System.EventHandler(this.numLeft_ValueChanged);

            this.btnSendLeft.Location = new System.Drawing.Point(255, 40);
            this.btnSendLeft.Name = "btnSendLeft";
            this.btnSendLeft.Size = new System.Drawing.Size(75, 23);
            this.btnSendLeft.TabIndex = 2;
            this.btnSendLeft.Text = "Send Left";
            this.btnSendLeft.UseVisualStyleBackColor = true;
            this.btnSendLeft.Click += new System.EventHandler(this.btnSendLeft_Click);

            this.lblRightMotor.AutoSize = true;
            this.lblRightMotor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblRightMotor.Location = new System.Drawing.Point(10, 88);
            this.lblRightMotor.Name = "lblRightMotor";
            this.lblRightMotor.Text = "Right motor (DAC2)";

            this.trkRight.LargeChange = 10;
            this.trkRight.Location = new System.Drawing.Point(6, 106);
            this.trkRight.Maximum = 255;
            this.trkRight.Name = "trkRight";
            this.trkRight.Size = new System.Drawing.Size(180, 45);
            this.trkRight.TabIndex = 3;
            this.trkRight.TickFrequency = 32;
            this.trkRight.Value = 128;
            this.trkRight.Scroll += new System.EventHandler(this.trkRight_Scroll);

            this.numRight.Location = new System.Drawing.Point(192, 108);
            this.numRight.Maximum = new decimal(new int[] { 255, 0, 0, 0 });
            this.numRight.Name = "numRight";
            this.numRight.Size = new System.Drawing.Size(55, 20);
            this.numRight.TabIndex = 4;
            this.numRight.Value = new decimal(new int[] { 128, 0, 0, 0 });
            this.numRight.ValueChanged += new System.EventHandler(this.numRight_ValueChanged);

            this.btnSendRight.Location = new System.Drawing.Point(255, 106);
            this.btnSendRight.Name = "btnSendRight";
            this.btnSendRight.Size = new System.Drawing.Size(75, 23);
            this.btnSendRight.TabIndex = 5;
            this.btnSendRight.Text = "Send Right";
            this.btnSendRight.UseVisualStyleBackColor = true;
            this.btnSendRight.Click += new System.EventHandler(this.btnSendRight_Click);

            this.btnSendBoth.Location = new System.Drawing.Point(10, 158);
            this.btnSendBoth.Name = "btnSendBoth";
            this.btnSendBoth.Size = new System.Drawing.Size(155, 28);
            this.btnSendBoth.TabIndex = 6;
            this.btnSendBoth.Text = "Send Both";
            this.btnSendBoth.UseVisualStyleBackColor = true;
            this.btnSendBoth.Click += new System.EventHandler(this.btnSendBoth_Click);

            this.btnNeutral.Location = new System.Drawing.Point(175, 158);
            this.btnNeutral.Name = "btnNeutral";
            this.btnNeutral.Size = new System.Drawing.Size(155, 28);
            this.btnNeutral.TabIndex = 7;
            this.btnNeutral.Text = "Neutral (128 / 128)";
            this.btnNeutral.UseVisualStyleBackColor = true;
            this.btnNeutral.Click += new System.EventHandler(this.btnNeutral_Click);

            this.chkLiveSend.AutoSize = true;
            this.chkLiveSend.Location = new System.Drawing.Point(12, 196);
            this.chkLiveSend.Name = "chkLiveSend";
            this.chkLiveSend.TabIndex = 8;
            this.chkLiveSend.Text = "Live control (send while moving sliders)";
            this.chkLiveSend.UseVisualStyleBackColor = true;
            this.chkLiveSend.CheckedChanged += new System.EventHandler(this.chkLiveSend_CheckedChanged);

            this.lblMotorHint.ForeColor = System.Drawing.Color.DimGray;
            this.lblMotorHint.Location = new System.Drawing.Point(10, 220);
            this.lblMotorHint.Name = "lblMotorHint";
            this.lblMotorHint.Size = new System.Drawing.Size(320, 26);
            this.lblMotorHint.Text = "128 = stop. Sending a motor value switches the robot to manual mode (line following pauses).";

            // ======================= SENSORS =======================
            this.grpSensors.Controls.Add(this.lblLeftIRTitle);
            this.grpSensors.Controls.Add(this.lblLeftValue);
            this.grpSensors.Controls.Add(this.prgLeft);
            this.grpSensors.Controls.Add(this.lblLeftSurface);
            this.grpSensors.Controls.Add(this.lblRightIRTitle);
            this.grpSensors.Controls.Add(this.lblRightValue);
            this.grpSensors.Controls.Add(this.prgRight);
            this.grpSensors.Controls.Add(this.lblRightSurface);
            this.grpSensors.Controls.Add(this.lblLeftMotorOutTitle);
            this.grpSensors.Controls.Add(this.lblLeftMotorOut);
            this.grpSensors.Controls.Add(this.lblRightMotorOutTitle);
            this.grpSensors.Controls.Add(this.lblRightMotorOut);
            this.grpSensors.Controls.Add(this.chkAutoPoll);
            this.grpSensors.Controls.Add(this.lblPollRate);
            this.grpSensors.Controls.Add(this.numPollRate);
            this.grpSensors.Controls.Add(this.btnReadNow);
            this.grpSensors.Location = new System.Drawing.Point(362, 12);
            this.grpSensors.Name = "grpSensors";
            this.grpSensors.Size = new System.Drawing.Size(340, 290);
            this.grpSensors.TabIndex = 3;
            this.grpSensors.TabStop = false;
            this.grpSensors.Text = "Sensor Readings";

            // Left IR
            this.lblLeftIRTitle.AutoSize = true;
            this.lblLeftIRTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblLeftIRTitle.Location = new System.Drawing.Point(10, 22);
            this.lblLeftIRTitle.Name = "lblLeftIRTitle";
            this.lblLeftIRTitle.Text = "Left IR (A6)";

            this.lblLeftValue.Font = new System.Drawing.Font("Consolas", 11F, System.Drawing.FontStyle.Bold);
            this.lblLeftValue.Location = new System.Drawing.Point(10, 40);
            this.lblLeftValue.Name = "lblLeftValue";
            this.lblLeftValue.Size = new System.Drawing.Size(210, 22);
            this.lblLeftValue.Text = "---";

            this.prgLeft.Location = new System.Drawing.Point(10, 66);
            this.prgLeft.Maximum = 255;
            this.prgLeft.Name = "prgLeft";
            this.prgLeft.Size = new System.Drawing.Size(210, 20);

            this.lblLeftSurface.BackColor = System.Drawing.Color.LightGray;
            this.lblLeftSurface.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLeftSurface.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblLeftSurface.Location = new System.Drawing.Point(230, 40);
            this.lblLeftSurface.Name = "lblLeftSurface";
            this.lblLeftSurface.Size = new System.Drawing.Size(100, 46);
            this.lblLeftSurface.Text = "---";
            this.lblLeftSurface.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // Right IR
            this.lblRightIRTitle.AutoSize = true;
            this.lblRightIRTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblRightIRTitle.Location = new System.Drawing.Point(10, 100);
            this.lblRightIRTitle.Name = "lblRightIRTitle";
            this.lblRightIRTitle.Text = "Right IR (A7)";

            this.lblRightValue.Font = new System.Drawing.Font("Consolas", 11F, System.Drawing.FontStyle.Bold);
            this.lblRightValue.Location = new System.Drawing.Point(10, 118);
            this.lblRightValue.Name = "lblRightValue";
            this.lblRightValue.Size = new System.Drawing.Size(210, 22);
            this.lblRightValue.Text = "---";

            this.prgRight.Location = new System.Drawing.Point(10, 144);
            this.prgRight.Maximum = 255;
            this.prgRight.Name = "prgRight";
            this.prgRight.Size = new System.Drawing.Size(210, 20);

            this.lblRightSurface.BackColor = System.Drawing.Color.LightGray;
            this.lblRightSurface.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRightSurface.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblRightSurface.Location = new System.Drawing.Point(230, 118);
            this.lblRightSurface.Name = "lblRightSurface";
            this.lblRightSurface.Size = new System.Drawing.Size(100, 46);
            this.lblRightSurface.Text = "---";
            this.lblRightSurface.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // Motor outputs reported by the robot
            this.lblLeftMotorOutTitle.AutoSize = true;
            this.lblLeftMotorOutTitle.Location = new System.Drawing.Point(10, 182);
            this.lblLeftMotorOutTitle.Name = "lblLeftMotorOutTitle";
            this.lblLeftMotorOutTitle.Text = "Left motor output:";

            this.lblLeftMotorOut.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.lblLeftMotorOut.Location = new System.Drawing.Point(115, 179);
            this.lblLeftMotorOut.Name = "lblLeftMotorOut";
            this.lblLeftMotorOut.Size = new System.Drawing.Size(50, 20);
            this.lblLeftMotorOut.Text = "---";

            this.lblRightMotorOutTitle.AutoSize = true;
            this.lblRightMotorOutTitle.Location = new System.Drawing.Point(175, 182);
            this.lblRightMotorOutTitle.Name = "lblRightMotorOutTitle";
            this.lblRightMotorOutTitle.Text = "Right motor output:";

            this.lblRightMotorOut.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.lblRightMotorOut.Location = new System.Drawing.Point(282, 179);
            this.lblRightMotorOut.Name = "lblRightMotorOut";
            this.lblRightMotorOut.Size = new System.Drawing.Size(50, 20);
            this.lblRightMotorOut.Text = "---";

            // Polling controls
            this.chkAutoPoll.AutoSize = true;
            this.chkAutoPoll.Checked = true;
            this.chkAutoPoll.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAutoPoll.Location = new System.Drawing.Point(12, 220);
            this.chkAutoPoll.Name = "chkAutoPoll";
            this.chkAutoPoll.TabIndex = 0;
            this.chkAutoPoll.Text = "Auto-refresh readings";
            this.chkAutoPoll.UseVisualStyleBackColor = true;

            this.lblPollRate.AutoSize = true;
            this.lblPollRate.Location = new System.Drawing.Point(175, 221);
            this.lblPollRate.Name = "lblPollRate";
            this.lblPollRate.Text = "Every (ms):";

            this.numPollRate.Increment = new decimal(new int[] { 50, 0, 0, 0 });
            this.numPollRate.Location = new System.Drawing.Point(245, 218);
            this.numPollRate.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            this.numPollRate.Minimum = new decimal(new int[] { 50, 0, 0, 0 });
            this.numPollRate.Name = "numPollRate";
            this.numPollRate.Size = new System.Drawing.Size(85, 20);
            this.numPollRate.TabIndex = 1;
            this.numPollRate.Value = new decimal(new int[] { 200, 0, 0, 0 });
            this.numPollRate.ValueChanged += new System.EventHandler(this.numPollRate_ValueChanged);

            this.btnReadNow.Location = new System.Drawing.Point(10, 250);
            this.btnReadNow.Name = "btnReadNow";
            this.btnReadNow.Size = new System.Drawing.Size(320, 28);
            this.btnReadNow.TabIndex = 2;
            this.btnReadNow.Text = "Read Sensors Now";
            this.btnReadNow.UseVisualStyleBackColor = true;
            this.btnReadNow.Click += new System.EventHandler(this.btnReadNow_Click);

            // ======================= LOG =======================
            this.grpLog.Controls.Add(this.lstLog);
            this.grpLog.Controls.Add(this.chkRecord);
            this.grpLog.Controls.Add(this.btnInspector);
            this.grpLog.Location = new System.Drawing.Point(362, 308);
            this.grpLog.Name = "grpLog";
            this.grpLog.Size = new System.Drawing.Size(340, 301);
            this.grpLog.TabIndex = 4;
            this.grpLog.TabStop = false;
            this.grpLog.Text = "Log";

            this.lstLog.FormattingEnabled = true;
            this.lstLog.HorizontalScrollbar = true;
            this.lstLog.Location = new System.Drawing.Point(10, 20);
            this.lstLog.Name = "lstLog";
            this.lstLog.Size = new System.Drawing.Size(320, 238);
            this.lstLog.TabIndex = 0;

            this.chkRecord.AutoSize = true;
            this.chkRecord.Checked = true;
            this.chkRecord.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRecord.Location = new System.Drawing.Point(12, 270);
            this.chkRecord.Name = "chkRecord";
            this.chkRecord.TabIndex = 1;
            this.chkRecord.Text = "Save packets to CSV";
            this.chkRecord.UseVisualStyleBackColor = true;
            this.chkRecord.CheckedChanged += new System.EventHandler(this.chkRecord_CheckedChanged);

            this.btnInspector.Location = new System.Drawing.Point(175, 265);
            this.btnInspector.Name = "btnInspector";
            this.btnInspector.Size = new System.Drawing.Size(155, 26);
            this.btnInspector.TabIndex = 2;
            this.btnInspector.Text = "Packet Inspector...";
            this.btnInspector.UseVisualStyleBackColor = true;
            this.btnInspector.Click += new System.EventHandler(this.btnInspector_Click);

            // ======================= FORM =======================
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(714, 621);
            this.Controls.Add(this.grpConnection);
            this.Controls.Add(this.grpRobot);
            this.Controls.Add(this.grpMotors);
            this.Controls.Add(this.grpSensors);
            this.Controls.Add(this.grpLog);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Line Following Robot - Control Panel";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);

            this.grpConnection.ResumeLayout(false);
            this.grpConnection.PerformLayout();
            this.grpRobot.ResumeLayout(false);
            this.grpRobot.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTurn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRight)).EndInit();
            this.grpMotors.ResumeLayout(false);
            this.grpMotors.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPollRate)).EndInit();
            this.grpSensors.ResumeLayout(false);
            this.grpSensors.PerformLayout();
            this.grpLog.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.IO.Ports.SerialPort serial;
        private System.Windows.Forms.Timer getIOtimer;
        private System.Windows.Forms.Timer pollTimer;
        private System.Windows.Forms.Timer liveTimer;

        private System.Windows.Forms.GroupBox grpConnection;
        private System.Windows.Forms.Label lblPort;
        private System.Windows.Forms.ComboBox cmbPort;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label lblConnStatus;

        private System.Windows.Forms.GroupBox grpRobot;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label lblModeTitle;
        private System.Windows.Forms.Label lblMode;
        private System.Windows.Forms.Label lblSpeedTitle;
        private System.Windows.Forms.TrackBar trkSpeed;
        private System.Windows.Forms.Label lblSpeedValue;
        private System.Windows.Forms.Label lblTurnTitle;
        private System.Windows.Forms.NumericUpDown numTurn;
        private System.Windows.Forms.CheckBox chkStopWheel;
        private System.Windows.Forms.CheckBox chkRecord;
        private System.Windows.Forms.Button btnInspector;
        private System.Windows.Forms.Label lblDirTitle;
        private System.Windows.Forms.RadioButton rdoForward;
        private System.Windows.Forms.RadioButton rdoReverse;

        private System.Windows.Forms.GroupBox grpMotors;
        private System.Windows.Forms.Label lblLeftMotor;
        private System.Windows.Forms.TrackBar trkLeft;
        private System.Windows.Forms.NumericUpDown numLeft;
        private System.Windows.Forms.Button btnSendLeft;
        private System.Windows.Forms.Label lblRightMotor;
        private System.Windows.Forms.TrackBar trkRight;
        private System.Windows.Forms.NumericUpDown numRight;
        private System.Windows.Forms.Button btnSendRight;
        private System.Windows.Forms.Button btnSendBoth;
        private System.Windows.Forms.Button btnNeutral;
        private System.Windows.Forms.CheckBox chkLiveSend;
        private System.Windows.Forms.Label lblMotorHint;

        private System.Windows.Forms.GroupBox grpSensors;
        private System.Windows.Forms.Label lblLeftIRTitle;
        private System.Windows.Forms.Label lblLeftValue;
        private System.Windows.Forms.ProgressBar prgLeft;
        private System.Windows.Forms.Label lblLeftSurface;
        private System.Windows.Forms.Label lblRightIRTitle;
        private System.Windows.Forms.Label lblRightValue;
        private System.Windows.Forms.ProgressBar prgRight;
        private System.Windows.Forms.Label lblRightSurface;
        private System.Windows.Forms.Label lblLeftMotorOutTitle;
        private System.Windows.Forms.Label lblLeftMotorOut;
        private System.Windows.Forms.Label lblRightMotorOutTitle;
        private System.Windows.Forms.Label lblRightMotorOut;
        private System.Windows.Forms.CheckBox chkAutoPoll;
        private System.Windows.Forms.Label lblPollRate;
        private System.Windows.Forms.NumericUpDown numPollRate;
        private System.Windows.Forms.Button btnReadNow;

        private System.Windows.Forms.GroupBox grpLog;
        private System.Windows.Forms.ListBox lstLog;
    }
}
