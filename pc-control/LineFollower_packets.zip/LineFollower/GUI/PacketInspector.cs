// Curtin University
// Mechatronics Engineering
// White Line Following Robot - PACKET MONITOR + PACKET INSPECTOR WINDOW
//
// PacketMonitor
//   Sees every packet the GUI sends and receives and keeps track of:
//     - every request that expects a reply (sensor / status / link stats)
//     - which reply packets came back, and how long they took (round trip)
//     - replies that never came back within the timeout  -> LOST
//     - replies where only some packets came back         -> PARTIAL
//     - packets with a bad checksum                       -> BAD
//     - stray bytes thrown away while re-synchronising    -> STRAY
//   Commands with no reply (START, STOP, motor, speed ...) cannot be
//   confirmed one by one, so the robot's own "packets received" counter
//   (command 11) is used to work out how many PC -> robot packets were
//   lost on the way.
//
//   Everything can be recorded to a CSV file (one line per packet, plus
//   one line per lost reply, and a summary at the end) that opens in Excel.
//
// PacketInspectorForm
//   A live window showing the packets and the link statistics.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace SerialGUISample
{
    // ====================================================================
    // ONE LINE IN THE INSPECTOR / CSV FILE
    // ====================================================================

    public class PacketEntry
    {
        public long Seq;
        public DateTime Time;
        public double ElapsedMs;
        public string Dir;        // TX, RX, LOST, PARTIAL, BAD, STRAY
        public int Port = -1;
        public int Data = -1;
        public string Name = "";
        public string Raw = "";
        public string Status = "";
        public double RttMs = -1;
        public bool Routine;      // routine polling traffic (can be hidden)
        public bool Problem;      // something went wrong

        public static string CsvHeader()
        {
            return "Seq,Time,Elapsed_ms,Direction,Port,Name,Data,Raw_hex,Status,RTT_ms";
        }

        public string ToCsv()
        {
            return Seq + ","
                + Time.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture) + ","
                + ElapsedMs.ToString("0.0", CultureInfo.InvariantCulture) + ","
                + Dir + ","
                + (Port >= 0 ? Port.ToString() : "") + ","
                + Csv(Name) + ","
                + (Data >= 0 ? Data.ToString() : "") + ","
                + Raw + ","
                + Csv(Status) + ","
                + (RttMs >= 0 ? RttMs.ToString("0.0", CultureInfo.InvariantCulture) : "");
        }

        static string Csv(string s)
        {
            if (s.IndexOf(',') >= 0 || s.IndexOf('"') >= 0)
                return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }
    }

    // ====================================================================
    // PACKET MONITOR (no UI - always running while connected)
    // ====================================================================

    public class PacketMonitor
    {
        // ---- protocol (must match Robot_Nano.ino) ----
        public const byte CMD_INPUT1 = 0;
        public const byte CMD_INPUT2 = 1;
        public const byte CMD_STATUS = 6;
        public const byte CMD_ALL = 10;
        public const byte CMD_LINK = 11;

        public const byte PORT_RX_GOOD = 10;
        public const byte PORT_RX_BAD = 11;
        public const byte PORT_RX_STRAY = 12;

        static readonly string[] TxNames = {
            "REQ LEFT IR", "REQ RIGHT IR", "SET LEFT MOTOR", "SET RIGHT MOTOR",
            "START", "STOP", "REQ STATUS", "SET SPEED", "SET CORRECTION",
            "SET DIRECTION", "REQ ALL", "REQ LINK STATS"
        };

        static string TxName(int port)
        {
            return port >= 0 && port < TxNames.Length ? TxNames[port] : "UNKNOWN CMD " + port;
        }

        static string RxName(int port)
        {
            switch (port)
            {
                case 0: return "LEFT IR";
                case 1: return "RIGHT IR";
                case 6: return "LEFT MOTOR OUT";
                case 7: return "RIGHT MOTOR OUT";
                case 8: return "MODE";
                case 9: return "DIRECTION";
                case 10: return "ROBOT RX GOOD";
                case 11: return "ROBOT RX BAD";
                case 12: return "ROBOT STRAY BYTES";
                default: return "UNKNOWN PORT " + port;
            }
        }

        // Reply ports each request expects
        static int[] ExpectedReplies(byte cmd)
        {
            switch (cmd)
            {
                case CMD_INPUT1: return new int[] { 0 };
                case CMD_INPUT2: return new int[] { 1 };
                case CMD_STATUS: return new int[] { 6, 7, 8, 9 };
                case CMD_ALL: return new int[] { 0, 1, 6, 7, 8, 9 };
                case CMD_LINK: return new int[] { 10, 11, 12 };
                default: return null;
            }
        }

        static bool IsRoutine(int txPort)
        {
            return txPort == CMD_INPUT1 || txPort == CMD_INPUT2 || txPort == CMD_STATUS
                || txPort == CMD_ALL || txPort == CMD_LINK;
        }

        class Pending
        {
            public long Seq;
            public byte Cmd;
            public double SentMs;
            public int Expected;
            public List<int> Waiting;
            public long TxCountAtSend;   // for the link-stats calculation
            public double LastRxMs = -1; // when its last reply packet arrived
        }

        // ---- settings ----
        public int TimeoutMs = 500;

        // ---- counters ----
        public long TxPackets, TxBytes, RxPackets, RxBytes;
        public long BadPackets, StrayBytes, UnsolicitedPackets;
        public long Requests, RepliesComplete, RepliesPartial, RepliesLost;
        public long ReplyPacketsExpected, ReplyPacketsLost;
        public double RttSum, RttMin = double.MaxValue, RttMax;
        public long RttCount;
        public double LastRtt = -1;

        // PC -> robot (uplink) loss from the robot's own counters
        bool statsBaselineSet, badBaselineSet, strayBaselineSet;
        int lastRobotGood, lastRobotBad, lastRobotStray;
        long txBaseline;
        public long UplinkSent, UplinkReceived;     // since baseline
        public long RobotBadTotal, RobotStrayTotal; // since baseline
        public bool UplinkKnown { get { return statsBaselineSet && UplinkSent > 0; } }

        // ---- internals ----
        readonly Stopwatch clock = Stopwatch.StartNew();
        readonly List<Pending> pending = new List<Pending>();
        long seq;

        StreamWriter recorder;
        public string RecordPath { get; private set; }
        public bool Recording { get { return recorder != null; } }
        double lastFlushMs;

        public event Action<PacketEntry> EntryAdded;

        double Now() { return clock.Elapsed.TotalMilliseconds; }

        // ----------------------------------------------------------------
        // RESET (new connection)
        // ----------------------------------------------------------------
        public void Reset()
        {
            TxPackets = TxBytes = RxPackets = RxBytes = 0;
            BadPackets = StrayBytes = UnsolicitedPackets = 0;
            Requests = RepliesComplete = RepliesPartial = RepliesLost = 0;
            ReplyPacketsExpected = ReplyPacketsLost = 0;
            RttSum = 0; RttMin = double.MaxValue; RttMax = 0; RttCount = 0; LastRtt = -1;
            statsBaselineSet = badBaselineSet = strayBaselineSet = false;
            UplinkSent = UplinkReceived = RobotBadTotal = RobotStrayTotal = 0;
            pending.Clear();
            seq = 0;
            clock.Reset();
            clock.Start();
            lastFlushMs = 0;
        }

        // ----------------------------------------------------------------
        // RECORDING TO CSV
        // ----------------------------------------------------------------
        public static string DefaultFolder()
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "LineFollowerPacketLogs");
        }

        public string StartRecording()
        {
            StopRecording();
            string folder = DefaultFolder();
            Directory.CreateDirectory(folder);
            string path = Path.Combine(folder,
                "packets_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv");
            recorder = new StreamWriter(path, false, Encoding.UTF8);
            recorder.WriteLine(PacketEntry.CsvHeader());
            RecordPath = path;
            return path;
        }

        public void StopRecording()
        {
            if (recorder == null) return;
            try
            {
                recorder.WriteLine();
                foreach (string line in SummaryLines())
                    recorder.WriteLine("# " + line.Replace(",", ";"));
                recorder.Flush();
                recorder.Close();
            }
            catch { }
            recorder = null;
        }

        // ----------------------------------------------------------------
        // EVENTS FROM THE GUI
        // ----------------------------------------------------------------

        public void Sent(byte port, byte data)
        {
            TxPackets++;
            TxBytes += 4;

            PacketEntry e = NewEntry("TX", port, data);
            e.Name = TxName(port);
            e.Routine = IsRoutine(port);

            int[] expect = ExpectedReplies(port);
            if (expect != null)
            {
                Requests++;
                ReplyPacketsExpected += expect.Length;
                Pending p = new Pending();
                p.Seq = e.Seq;
                p.Cmd = port;
                p.SentMs = e.ElapsedMs;
                p.Expected = expect.Length;
                p.Waiting = new List<int>(expect);
                p.TxCountAtSend = TxPackets;
                pending.Add(p);
                e.Status = "waiting for " + expect.Length + " reply packet(s)";
            }
            else
            {
                e.Status = "sent (no reply expected)";
            }

            Add(e);
        }

        public void Received(byte port, byte data)
        {
            RxPackets++;
            RxBytes += 4;

            PacketEntry e = NewEntry("RX", port, data);
            e.Name = RxName(port);

            // Which request is this a reply to? (The 4-byte protocol has no
            // sequence numbers, so this is worked out from timing.)
            //  - normally the NEWEST request waiting for this port; an
            //    older one still waiting has almost certainly lost its reply
            //  - except when an older request's reply burst is still
            //    arriving (a packet came in the last 50 ms, after the newer
            //    request was sent)
            Pending match = null;
            for (int i = pending.Count - 1; i >= 0; i--)
            {
                if (pending[i].Waiting.Contains(port)) { match = pending[i]; break; }
            }
            if (match != null)
            {
                foreach (Pending p in pending)
                {
                    if (p != match && p.Waiting.Contains(port) && p.LastRxMs >= 0
                        && e.ElapsedMs - p.LastRxMs < 50 && p.LastRxMs > match.SentMs)
                    {
                        match = p;
                        break;
                    }
                }
            }

            if (match == null)
            {
                UnsolicitedPackets++;
                e.Status = "UNEXPECTED (no request waiting / reply too late)";
                e.Problem = true;
            }
            else
            {
                e.Routine = true;
                match.Waiting.Remove(port);
                match.LastRxMs = e.ElapsedMs;
                if (match.Waiting.Count == 0)
                {
                    pending.Remove(match);
                    RepliesComplete++;
                    double rtt = e.ElapsedMs - match.SentMs;
                    e.RttMs = rtt;
                    LastRtt = rtt;
                    RttSum += rtt; RttCount++;
                    if (rtt < RttMin) RttMin = rtt;
                    if (rtt > RttMax) RttMax = rtt;
                    e.Status = "reply to #" + match.Seq + " complete";
                }
                else
                {
                    e.Status = "reply to #" + match.Seq;
                }

                if (match.Cmd == CMD_LINK) HandleLinkStat(port, data, match);
            }

            Add(e);
        }

        public void BadPacket(byte[] raw)
        {
            BadPackets++;
            PacketEntry e = NewEntry("BAD", raw[1], raw[2]);
            e.Raw = Hex(raw);
            e.Name = "BAD CHECKSUM";
            e.Status = "corrupted or out of sync - re-synchronising";
            e.Problem = true;
            Add(e);
        }

        public void Stray(int count)
        {
            if (count <= 0) return;
            StrayBytes += count;
            PacketEntry e = NewEntry("STRAY", -1, -1);
            e.Name = "STRAY BYTES";
            e.Status = count + " byte(s) discarded while searching for 255";
            e.Problem = true;
            Add(e);
        }

        // Call often (e.g. every 10 ms): finds lost replies, flushes the file
        public void Tick()
        {
            double now = Now();

            for (int i = pending.Count - 1; i >= 0; i--)
            {
                Pending p = pending[i];
                if (now - p.SentMs < TimeoutMs) continue;

                pending.RemoveAt(i);
                ReplyPacketsLost += p.Waiting.Count;

                PacketEntry e = NewEntry(p.Waiting.Count == p.Expected ? "LOST" : "PARTIAL", p.Cmd, -1);
                e.Name = TxName(p.Cmd);
                e.Problem = true;

                List<string> missing = new List<string>();
                foreach (int w in p.Waiting) missing.Add(RxName(w));

                if (p.Waiting.Count == p.Expected)
                {
                    RepliesLost++;
                    e.Status = "NO REPLY to #" + p.Seq + " within " + TimeoutMs + " ms";
                }
                else
                {
                    RepliesPartial++;
                    e.Status = "reply to #" + p.Seq + " missing " + p.Waiting.Count + " of "
                        + p.Expected + ": " + string.Join(" + ", missing.ToArray());
                }
                Add(e);
            }

            if (recorder != null && now - lastFlushMs > 250)
            {
                lastFlushMs = now;
                try { recorder.Flush(); } catch { }
            }
        }

        // ----------------------------------------------------------------
        // ROBOT LINK COUNTERS -> PC -> ROBOT LOSS
        // The robot counts every good packet it receives (8-bit counter).
        // Comparing the increase with how many packets we sent tells us how
        // many of our packets never arrived.
        // ----------------------------------------------------------------
        void HandleLinkStat(byte port, byte data, Pending p)
        {
            if (port == PORT_RX_GOOD)
            {
                if (!statsBaselineSet)
                {
                    // first reply = starting point
                    statsBaselineSet = true;
                    txBaseline = p.TxCountAtSend;
                }
                else
                {
                    UplinkReceived += (data - lastRobotGood) & 0xFF;
                    UplinkSent = p.TxCountAtSend - txBaseline;
                }
                lastRobotGood = data;
            }
            else if (port == PORT_RX_BAD)
            {
                if (badBaselineSet) RobotBadTotal += (data - lastRobotBad) & 0xFF;
                badBaselineSet = true;
                lastRobotBad = data;
            }
            else if (port == PORT_RX_STRAY)
            {
                if (strayBaselineSet) RobotStrayTotal += (data - lastRobotStray) & 0xFF;
                strayBaselineSet = true;
                lastRobotStray = data;
            }
        }

        // ----------------------------------------------------------------
        // STATISTICS
        // ----------------------------------------------------------------

        public double DownlinkLossPercent
        {
            get
            {
                long done = ReplyPacketsExpected - PendingReplyPackets();
                return done > 0 ? 100.0 * ReplyPacketsLost / done : 0;
            }
        }

        public double UplinkLossPercent
        {
            get
            {
                if (!UplinkKnown) return 0;
                long lost = Math.Max(0, UplinkSent - UplinkReceived);
                return 100.0 * lost / UplinkSent;
            }
        }

        long PendingReplyPackets()
        {
            long n = 0;
            foreach (Pending p in pending) n += p.Waiting.Count;
            return n;
        }

        public string ShortStatus()
        {
            string s = "lost: rx " + DownlinkLossPercent.ToString("0.0") + "%";
            if (UplinkKnown) s += ", tx " + UplinkLossPercent.ToString("0.0") + "%";
            return s;
        }

        public List<string> SummaryLines()
        {
            List<string> l = new List<string>();
            double secs = clock.Elapsed.TotalSeconds;
            l.Add("SUMMARY  (" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ", "
                + secs.ToString("0.0") + " s)");
            l.Add("PC -> robot : " + TxPackets + " packets sent (" + TxBytes + " bytes, "
                + (secs > 0 ? (TxBytes / secs).ToString("0") : "0") + " B/s)");
            if (UplinkKnown)
                l.Add("              robot received " + UplinkReceived + " of the last " + UplinkSent
                    + "  -> lost " + Math.Max(0, UplinkSent - UplinkReceived)
                    + " (" + UplinkLossPercent.ToString("0.0") + " %), robot saw "
                    + RobotBadTotal + " bad + " + RobotStrayTotal + " stray bytes");
            else
                l.Add("              robot receive counter not available yet (needs new robot code)");
            l.Add("Robot -> PC : " + RxPackets + " packets received (" + RxBytes + " bytes, "
                + (secs > 0 ? (RxBytes / secs).ToString("0") : "0") + " B/s)");
            l.Add("Requests    : " + Requests + " sent, " + RepliesComplete + " complete, "
                + RepliesPartial + " partial, " + RepliesLost + " no reply");
            l.Add("Reply pkts  : " + ReplyPacketsExpected + " expected, " + ReplyPacketsLost + " lost ("
                + DownlinkLossPercent.ToString("0.0") + " %)");
            l.Add("Errors      : " + BadPackets + " bad checksum, " + StrayBytes + " stray bytes, "
                + UnsolicitedPackets + " unexpected");
            if (RttCount > 0)
                l.Add("Round trip  : avg " + (RttSum / RttCount).ToString("0.0") + " ms, min "
                    + RttMin.ToString("0.0") + " ms, max " + RttMax.ToString("0.0") + " ms, last "
                    + LastRtt.ToString("0.0") + " ms");
            else
                l.Add("Round trip  : -");
            return l;
        }

        // ----------------------------------------------------------------
        // HELPERS
        // ----------------------------------------------------------------

        PacketEntry NewEntry(string dir, int port, int data)
        {
            PacketEntry e = new PacketEntry();
            e.Seq = ++seq;
            e.Time = DateTime.Now;
            e.ElapsedMs = Now();
            e.Dir = dir;
            e.Port = port;
            e.Data = data;
            if (port >= 0 && data >= 0 && (dir == "TX" || dir == "RX"))
                e.Raw = Hex(new byte[] { 255, (byte)port, (byte)data, (byte)(255 + port + data) });
            return e;
        }

        static string Hex(byte[] b)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte x in b)
            {
                if (sb.Length > 0) sb.Append(' ');
                sb.Append(x.ToString("X2"));
            }
            return sb.ToString();
        }

        void Add(PacketEntry e)
        {
            if (recorder != null)
            {
                try { recorder.WriteLine(e.ToCsv()); }
                catch { }
            }
            if (EntryAdded != null) EntryAdded(e);
        }
    }

    // ====================================================================
    // PACKET INSPECTOR WINDOW
    // ====================================================================

    public class PacketInspectorForm : Form
    {
        const int MAX_ROWS = 4000;

        readonly PacketMonitor monitor;
        readonly List<PacketEntry> history = new List<PacketEntry>();
        readonly List<PacketEntry> incoming = new List<PacketEntry>();
        bool needsRebuild;

        ListView list;
        Label lblStats;
        Label lblFile;
        CheckBox chkPause, chkProblemsOnly, chkHideRoutine, chkAutoScroll;
        NumericUpDown numTimeout;
        Timer refresh;

        public PacketInspectorForm(PacketMonitor monitor)
        {
            this.monitor = monitor;

            Text = "Packet Inspector";
            Size = new Size(1060, 660);
            MinimumSize = new Size(700, 400);
            StartPosition = FormStartPosition.CenterScreen;

            // ---- statistics ----
            lblStats = new Label();
            lblStats.Dock = DockStyle.Top;
            lblStats.Height = 128;
            lblStats.Font = new Font(FontFamily.GenericMonospace, 9F);
            lblStats.Padding = new Padding(6);
            lblStats.BackColor = Color.FromArgb(245, 245, 245);

            // ---- toolbar ----
            FlowLayoutPanel bar = new FlowLayoutPanel();
            bar.Dock = DockStyle.Top;
            bar.Height = 34;
            bar.Padding = new Padding(4, 4, 4, 0);
            bar.WrapContents = false;

            chkPause = MakeCheck("Pause view", false);
            chkProblemsOnly = MakeCheck("Problems only", false);
            chkHideRoutine = MakeCheck("Hide OK polling", false);
            chkAutoScroll = MakeCheck("Auto-scroll", true);
            chkPause.CheckedChanged += delegate { if (!chkPause.Checked) needsRebuild = true; };
            chkProblemsOnly.CheckedChanged += delegate { needsRebuild = true; };
            chkHideRoutine.CheckedChanged += delegate { needsRebuild = true; };

            Label lblTimeout = new Label();
            lblTimeout.Text = "Reply timeout (ms):";
            lblTimeout.AutoSize = true;
            lblTimeout.Margin = new Padding(10, 6, 0, 0);

            numTimeout = new NumericUpDown();
            numTimeout.Minimum = 50;
            numTimeout.Maximum = 5000;
            numTimeout.Increment = 50;
            numTimeout.Width = 60;
            numTimeout.Value = monitor.TimeoutMs;
            numTimeout.ValueChanged += delegate { monitor.TimeoutMs = (int)numTimeout.Value; };

            Button btnClear = MakeButton("Clear view");
            btnClear.Click += delegate { history.Clear(); incoming.Clear(); list.Items.Clear(); };

            Button btnReset = MakeButton("Reset counters");
            btnReset.Click += delegate { monitor.Reset(); history.Clear(); incoming.Clear(); list.Items.Clear(); };

            Button btnSave = MakeButton("Save view...");
            btnSave.Click += delegate { SaveView(); };

            Button btnFolder = MakeButton("Open log folder");
            btnFolder.Click += delegate
            {
                try
                {
                    Directory.CreateDirectory(PacketMonitor.DefaultFolder());
                    Process.Start(PacketMonitor.DefaultFolder());
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            };

            bar.Controls.AddRange(new Control[] {
                chkPause, chkProblemsOnly, chkHideRoutine, chkAutoScroll,
                lblTimeout, numTimeout, btnClear, btnReset, btnSave, btnFolder });

            // ---- recording file ----
            lblFile = new Label();
            lblFile.Dock = DockStyle.Bottom;
            lblFile.Height = 22;
            lblFile.Padding = new Padding(6, 4, 0, 0);
            lblFile.BackColor = Color.FromArgb(235, 235, 235);

            // ---- packet list ----
            list = new ListView();
            list.Dock = DockStyle.Fill;
            list.View = View.Details;
            list.FullRowSelect = true;
            list.GridLines = true;
            list.HideSelection = false;
            list.Font = new Font(FontFamily.GenericMonospace, 8.5F);
            list.Columns.Add("#", 60);
            list.Columns.Add("Time", 95);
            list.Columns.Add("Dir", 60);
            list.Columns.Add("Port", 40);
            list.Columns.Add("Name", 130);
            list.Columns.Add("Data", 45);
            list.Columns.Add("Raw bytes", 95);
            list.Columns.Add("RTT ms", 60);
            list.Columns.Add("Status", 330);

            Controls.Add(list);
            Controls.Add(bar);
            Controls.Add(lblStats);
            Controls.Add(lblFile);

            monitor.EntryAdded += OnEntry;

            refresh = new Timer();
            refresh.Interval = 250;
            refresh.Tick += delegate { RefreshView(); };
            refresh.Start();

            FormClosed += delegate
            {
                refresh.Stop();
                monitor.EntryAdded -= OnEntry;
            };

            RefreshView();
        }

        static CheckBox MakeCheck(string text, bool on)
        {
            CheckBox c = new CheckBox();
            c.Text = text;
            c.Checked = on;
            c.AutoSize = true;
            c.Margin = new Padding(4, 5, 4, 0);
            return c;
        }

        static Button MakeButton(string text)
        {
            Button b = new Button();
            b.Text = text;
            b.AutoSize = true;
            b.Height = 24;
            return b;
        }

        void OnEntry(PacketEntry e)
        {
            incoming.Add(e);
        }

        bool ShouldShow(PacketEntry e)
        {
            if (chkProblemsOnly.Checked && !e.Problem) return false;
            if (chkHideRoutine.Checked && e.Routine && !e.Problem) return false;
            return true;
        }

        void RefreshView()
        {
            // ---- statistics ----
            lblStats.Text = string.Join(Environment.NewLine, monitor.SummaryLines().ToArray());
            lblFile.Text = monitor.Recording
                ? "Recording to: " + monitor.RecordPath
                : "Not recording to a file (tick \"Save packets to CSV\" on the main window, then connect).";

            // ---- new packets ----
            if (incoming.Count > 0)
            {
                history.AddRange(incoming);
                if (history.Count > MAX_ROWS) history.RemoveRange(0, history.Count - MAX_ROWS);
            }

            if (chkPause.Checked)
            {
                incoming.Clear();
                return;
            }

            list.BeginUpdate();
            if (needsRebuild)
            {
                needsRebuild = false;
                list.Items.Clear();
                List<ListViewItem> rows = new List<ListViewItem>();
                foreach (PacketEntry e in history)
                    if (ShouldShow(e)) rows.Add(MakeRow(e));
                list.Items.AddRange(rows.ToArray());
            }
            else
            {
                List<ListViewItem> rows = new List<ListViewItem>();
                foreach (PacketEntry e in incoming)
                    if (ShouldShow(e)) rows.Add(MakeRow(e));
                list.Items.AddRange(rows.ToArray());
                while (list.Items.Count > MAX_ROWS) list.Items.RemoveAt(0);
            }
            incoming.Clear();

            if (chkAutoScroll.Checked && list.Items.Count > 0)
                list.EnsureVisible(list.Items.Count - 1);
            list.EndUpdate();
        }

        static ListViewItem MakeRow(PacketEntry e)
        {
            ListViewItem it = new ListViewItem(e.Seq.ToString());
            it.SubItems.Add(e.Time.ToString("HH:mm:ss.fff"));
            it.SubItems.Add(e.Dir);
            it.SubItems.Add(e.Port >= 0 ? e.Port.ToString() : "");
            it.SubItems.Add(e.Name);
            it.SubItems.Add(e.Data >= 0 ? e.Data.ToString() : "");
            it.SubItems.Add(e.Raw);
            it.SubItems.Add(e.RttMs >= 0 ? e.RttMs.ToString("0.0") : "");
            it.SubItems.Add(e.Status);

            switch (e.Dir)
            {
                case "TX": it.BackColor = Color.FromArgb(225, 238, 255); break;
                case "RX": it.BackColor = e.Problem ? Color.FromArgb(255, 243, 205) : Color.White; break;
                case "LOST": it.BackColor = Color.FromArgb(255, 205, 205); break;
                case "PARTIAL": it.BackColor = Color.FromArgb(255, 228, 196); break;
                case "BAD": it.BackColor = Color.FromArgb(255, 190, 150); break;
                case "STRAY": it.BackColor = Color.FromArgb(255, 250, 200); break;
            }
            return it;
        }

        void SaveView()
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "CSV file (*.csv)|*.csv";
            dlg.FileName = "packets_view_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv";
            if (dlg.ShowDialog(this) != DialogResult.OK) return;

            try
            {
                using (StreamWriter w = new StreamWriter(dlg.FileName, false, Encoding.UTF8))
                {
                    w.WriteLine(PacketEntry.CsvHeader());
                    foreach (PacketEntry e in history) w.WriteLine(e.ToCsv());
                    w.WriteLine();
                    foreach (string line in monitor.SummaryLines())
                        w.WriteLine("# " + line.Replace(",", ";"));
                }
                MessageBox.Show(this, "Saved " + history.Count + " packets to\n" + dlg.FileName,
                    "Packet Inspector");
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not save: " + ex.Message, "Packet Inspector");
            }
        }
    }
}
